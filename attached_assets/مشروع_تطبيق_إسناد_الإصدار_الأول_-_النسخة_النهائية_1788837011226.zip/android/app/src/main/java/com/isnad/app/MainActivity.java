package com.isnad.app;

import com.getcapacitor.BridgeActivity;

/**
 * نقطة الدخول الأصلية لتطبيق إسناد على أندرويد.
 * لا يوجد هنا أي منطق محاسبي — فقط تشغيل WebView عبر Capacitor Bridge،
 * الذي يحمّل web/index.html من assets/public ويُشغِّل نفس التطبيق ونفس IndexedDB
 * ونفس Repository ونفس محرك التوزيع الذي اختبرناه في المتصفح.
 */
public class MainActivity extends BridgeActivity {
}
