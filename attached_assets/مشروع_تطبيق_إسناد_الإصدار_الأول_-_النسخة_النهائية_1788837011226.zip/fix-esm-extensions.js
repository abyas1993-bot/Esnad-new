// إضافة امتداد .js لكل استيراد نسبي في الإخراج المُترجَم — مطلوب لوحدات ES الأصلية في المتصفح
const fs = require("fs");
const path = require("path");

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith(".js")) fixFile(full);
  }
}

function fixFile(file) {
  let content = fs.readFileSync(file, "utf-8");
  const fixed = content.replace(
    /(from\s+["'])(\.\.?\/[^"']+)(["'])/g,
    (match, pre, p, post) => {
      if (p.endsWith(".js")) return match;
      return `${pre}${p}.js${post}`;
    }
  );
  if (fixed !== content) {
    fs.writeFileSync(file, fixed, "utf-8");
    console.log("fixed:", file);
  }
}

walk(process.argv[2] || "web-dist");
