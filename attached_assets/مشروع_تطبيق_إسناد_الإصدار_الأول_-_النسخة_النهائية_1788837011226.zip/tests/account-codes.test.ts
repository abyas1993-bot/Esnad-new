// ============================================================
// اختبارات أكواد الحسابات الظاهرة ومجموعات دليل الحسابات — المرحلة الرابعة.
// تغطي: الترقيم التسلسلي لكل مجموعة، تسلسل "دائنون" المشترك بين recurring_debt وone_time_debt،
// تثبيت أكواد الحسابات القديمة (deterministic) دون المساس بأي حقل آخر، وعدم التكرار.
// ============================================================
import { Account, ACCOUNT_GROUPS, groupForCategory } from "../src/types";
import { FileStorageAdapter } from "../src/storage";
import { Repository } from "../src/repository";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;
const DB_FILE = "/tmp/isnad_test_account_codes_db.json";

async function main() {
  const fs = require("fs");

  console.log("=== 1) خريطة المجموعات الثمانية بالترتيب الثابت وربطها بالفئات ===\n");
  {
    assertEqual(ACCOUNT_GROUPS.map((g) => g.n), [1, 2, 3, 4, 5, 6, 7, 8], "1-أ: أرقام المجموعات 1..8 بالترتيب");
    assertEqual(ACCOUNT_GROUPS.map((g) => g.label), ["دخل", "أوعية", "مصروفات", "أهداف", "إدخار", "دائنون", "مقتنيات", "أخرى"], "1-ب: تسميات المجموعات بالترتيب المطلوب");
    assertEqual(groupForCategory("income_source")?.n, 1, "1-ج: income_source → المجموعة 1 (دخل)");
    assertEqual(groupForCategory("pot")?.n, 2, "1-د: pot → المجموعة 2 (أوعية)");
    assertEqual(groupForCategory("expense")?.n, 3, "1-هـ: expense → المجموعة 3 (مصروفات)");
    assertEqual(groupForCategory("goal")?.n, 4, "1-و: goal → المجموعة 4 (أهداف)");
    assertEqual(groupForCategory("reserve")?.n, 5, "1-ز: reserve → المجموعة 5 (إدخار)");
    assertEqual(groupForCategory("recurring_debt")?.n, 6, "1-ح: recurring_debt → المجموعة 6 (دائنون)");
    assertEqual(groupForCategory("one_time_debt")?.n, 6, "1-ط: one_time_debt → المجموعة 6 (دائنون) أيضًا — نفس المجموعة");
    assertEqual(groupForCategory("asset")?.n, 7, "1-ي: asset → المجموعة 7 (مقتنيات)");
    assertEqual(ACCOUNT_GROUPS.find((g) => g.n === 8)?.categories, [], "1-ك: المجموعة 8 (أخرى) فارغة عمدًا — بلا أي فئة مُسنَدة تلقائيًا");
  }

  console.log("\n=== 2) الكود التالي المتاح يتسلسل داخل كل مجموعة بشكل مستقل ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    assertEqual(await repo.getNextAccountCode("income_source"), "1001", "2-أ: أول كود في مجموعة دخل فارغة = 1001");
    assertEqual(await repo.getNextAccountCode("pot"), "2001", "2-ب: أول كود في مجموعة أوعية فارغة = 2001 (مستقلة عن مجموعة الدخل)");

    const salary = acc("acc_salary", "الراتب", "income_source");
    (salary as any).code = "1001";
    await repo.saveAccount(salary);
    assertEqual(await repo.getNextAccountCode("income_source"), "1002", "2-ج: بعد حجز 1001 يصبح التالي 1002 لنفس المجموعة");
    assertEqual(await repo.getNextAccountCode("pot"), "2001", "2-د: مجموعة أوعية غير متأثرة إطلاقًا بما حدث في مجموعة الدخل");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 3) مجموعة \"دائنون\": تسلسل كود واحد مشترك بين recurring_debt وone_time_debt ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    assertEqual(await repo.getNextAccountCode("recurring_debt"), "6001", "3-أ: أول كود لدين مستمر في مجموعة فارغة = 6001");

    const debt1 = acc("acc_debt1", "دين مستمر 1", "recurring_debt");
    (debt1 as any).code = "6001";
    await repo.saveAccount(debt1);

    assertEqual(await repo.getNextAccountCode("one_time_debt"), "6002", "3-ب: التالي لدين لمرة واحدة = 6002 (يكمل تسلسل دائنون المشترك، لا يبدأ من جديد)");

    const debt2 = acc("acc_debt2", "دين لمرة واحدة 1", "one_time_debt");
    (debt2 as any).code = "6002";
    await repo.saveAccount(debt2);

    assertEqual(await repo.getNextAccountCode("recurring_debt"), "6003", "3-ج: العودة لدين مستمر تعطي 6003 — نفس التسلسل المشترك مستمر بلا تصادم");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 4) الحسابات الجديدة عبر Repository.saveAccount + getNextAccountCode لا تتكرر أكوادها ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const codes: string[] = [];
    for (let i = 0; i < 5; i++) {
      const code = await repo.getNextAccountCode("expense");
      codes.push(code);
      const a = acc(`acc_exp_${i}`, `مصروف ${i}`, "expense");
      (a as any).code = code;
      await repo.saveAccount(a);
    }
    assertEqual(codes, ["3001", "3002", "3003", "3004", "3005"], "4-أ: خمسة حسابات مصروف متتالية تحصل على 3001..3005 بلا فجوة ولا تكرار");
    assertEqual(new Set(codes).size, codes.length, "4-ب: كل الأكواد المُصدَرة فريدة تمامًا");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 5) تثبيت أكواد الحسابات القديمة (ensureAccountCodesAssigned): مستقر، لا يمسّ أي حقل آخر ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const legacyDump = {
      accounts: {
        acc_1000_1_aaa: { id: "acc_1000_1_aaa", name: "المحفظة", category: "pot", openingBalance: 500, status: "active" },
        acc_1000_2_bbb: { id: "acc_1000_2_bbb", name: "التوفير", category: "pot", openingBalance: 0, status: "archived" },
        acc_1000_3_ccc: { id: "acc_1000_3_ccc", name: "الراتب", category: "income_source", openingBalance: 0, status: "active" },
      },
      journalEntries: [],
      periods: {}, periodCloseResults: {}, planningSettings: {}, currencies: {}, accountCurrencyLinks: {},
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(legacyDump, null, 2), "utf-8");

    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    await repo.ensureAccountCodesAssigned();
    const afterFirstRun = await repo.getAllAccounts();
    const byId = new Map(afterFirstRun.map((a) => [a.id, a]));

    assertEqual(byId.get("acc_1000_1_aaa")?.code, "2001", "5-أ: أقدم حساب وعاء (بترتيب id) يحصل على أول كود في مجموعته (2001)");
    assertEqual(byId.get("acc_1000_2_bbb")?.code, "2002", "5-ب: الوعاء الثاني يحصل على 2002 (نفس مجموعة أوعية، تسلسل مستقل عن الدخل)");
    assertEqual(byId.get("acc_1000_3_ccc")?.code, "1001", "5-ج: حساب الدخل الوحيد يحصل على 1001 (مجموعته الخاصة)");

    assertEqual(byId.get("acc_1000_1_aaa")?.id, "acc_1000_1_aaa", "5-د: id لم يتغيّر");
    assertEqual(byId.get("acc_1000_1_aaa")?.category, "pot", "5-هـ: category لم تتغيّر");
    assertEqual(byId.get("acc_1000_1_aaa")?.openingBalance, 500, "5-و: openingBalance لم يتغيّر");
    assertEqual(byId.get("acc_1000_2_bbb")?.status, "archived", "5-ز: status لم تتغيّر (حتى لحساب مؤرشف)");

    await repo.ensureAccountCodesAssigned();
    const afterSecondRun = await repo.getAllAccounts();
    const byId2 = new Map(afterSecondRun.map((a) => [a.id, a]));
    assertEqual(byId2.get("acc_1000_1_aaa")?.code, "2001", "5-ح: الاستدعاء الثاني idempotent — نفس الكود بالضبط دون تغيير");
    assertEqual(byId2.get("acc_1000_2_bbb")?.code, "2002", "5-ط: نفس الشيء للحساب الثاني");
    assertEqual(byId2.get("acc_1000_3_ccc")?.code, "1001", "5-ي: ونفس الشيء لحساب الدخل");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 6) مزيج: حسابات قديمة بلا كود + حساب جديد بكود صريح مسبقًا — لا تصادم عند التثبيت ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const modernCode = await repo.getNextAccountCode("pot");
    const modernAccount = acc("acc_modern", "وعاء حديث", "pot");
    (modernAccount as any).code = modernCode;
    await repo.saveAccount(modernAccount);
    assertEqual(modernCode, "2001", "6-أ: الحساب الحديث يحصل على 2001 فور إنشائه");

    const legacyAccount = acc("acc_legacy", "وعاء قديم", "pot");
    await repo.saveAccount(legacyAccount);

    await repo.ensureAccountCodesAssigned();
    const all = await repo.getAllAccounts();
    const byId = new Map(all.map((a) => [a.id, a]));

    assertEqual(byId.get("acc_modern")?.code, "2001", "6-ب: الحساب الحديث يحتفظ بكوده الصريح 2001 دون أي تغيير");
    assertEqual(byId.get("acc_legacy")?.code, "2002", "6-ج: الحساب القديم يحصل على 2002 — يكمل بعد أعلى كود موجود، لا يتصادم معه");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات أكواد الحسابات: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات أكواد الحسابات:", e);
  process.exit(1);
});
