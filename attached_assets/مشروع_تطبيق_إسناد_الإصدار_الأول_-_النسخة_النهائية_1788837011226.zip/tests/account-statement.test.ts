// ============================================================
// اختبارات "كشف الحساب" — المرحلة الخامسة، الخطوة 1.
// تكمل tests/reports.test.ts (غير المُعدَّل) — تغطي تحديدًا: احتساب الرصيد الافتتاحي
// الصحيح للفترة (openingBalance + أثر القيود السابقة لـfromDate)، الرصيد الجاري، عرض
// العملة، عمود operationNumber، والحساب بلا حركات ضمن الفترة.
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { recordIncome, recordExpense, recordTransfer } from "../src/transactions";
import { computeBalance } from "../src/ledger";
import { buildAccountLedgerReport } from "../src/reports";
import { Currency } from "../src/currency";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
function acc(id: string, name: string, category: Account["category"], opening = 0): Account {
  return { id, name, category, openingBalance: opening, status: "active" };
}
function num(cell: string): number {
  return Number(cell.replace(/[^\d.-]/g, ""));
}

const wallet = acc("acc_wallet", "المحفظة", "pot");
const salary = acc("acc_salary", "الراتب", "income_source");
const food = acc("acc_food", "طعام", "expense");
const allAccounts = [wallet, salary, food];

console.log("=== 1) كشف حساب بلا fromDate: الرصيد الافتتاحي = openingBalance كما كان دائمًا ===\n");
{
  const walletWithOpening = acc("acc_w_open", "محفظة بافتتاحي", "pot", 5000);
  const entries: JournalEntry[] = [recordIncome(salary, walletWithOpening, 1000, "2026-08-01", "p1")];
  const report = buildAccountLedgerReport({ account: walletWithOpening, allAccounts: [...allAccounts, walletWithOpening], entries });
  assertEqual(report.totals?.["الرصيد الافتتاحي"], (5000).toLocaleString("en-US"), "1-أ: الرصيد الافتتاحي في totals = 5,000 (بلا fromDate، مطابق لـopeningBalance)");
  assertEqual(num(report.totals!["الرصيد النهائي"]), 6000, "1-ب: الرصيد النهائي = 6,000");
}

console.log("\n=== 2) كشف حساب مع fromDate: الرصيد الافتتاحي = openingBalance + أثر القيود السابقة لـfromDate (وليس openingBalance وحده) ===\n");
{
  const w = acc("acc_w2", "محفظة", "pot", 0);
  const entries: JournalEntry[] = [
    recordIncome(salary, w, 50000, "2026-08-01", "p1"), // قبل fromDate — يجب احتسابه ضمن الافتتاحي
    recordExpense(food, w, 12000, "2026-08-15", "p1", false, 50000), // قبل fromDate أيضًا
    recordIncome(salary, w, 10000, "2026-09-01", "p2"), // ضمن الفترة (from 2026-09-01)
  ];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries, fromDate: "2026-09-01" });

  assertEqual(num(report.totals!["الرصيد الافتتاحي"]), 38000, "2-أ: الرصيد الافتتاحي للفترة = 38,000 (openingBalance صفر + أثر قيدَي أغسطس)");
  assertEqual(report.rows.length, 1, "2-ب: سطر واحد فقط ضمن rows (حركة سبتمبر) — لا سطر افتتاحي منفصل يُضاف لـrows مع fromDate");
  assertEqual(num(report.rows[0][5]), 48000, "2-ج: الرصيد المتحرك في سطر سبتمبر = 48,000 (يبدأ من الافتتاحي الصحيح 38,000 + 10,000)");
  assertEqual(num(report.totals!["الرصيد النهائي"]), 48000, "2-د: الرصيد النهائي = 48,000 — يطابق الرصيد الفعلي الحقيقي للحساب حتى الآن");
  assertEqual(num(report.totals!["الرصيد النهائي"]), computeBalance(w, entries), "2-هـ: الرصيد النهائي يطابق computeBalance الحقيقية تمامًا (لا أثر لفلترة العرض على الحساب الفعلي)");
}

console.log("\n=== 3) حركة خارج الفترة (بعد toDate) لا تُحتسَب إطلاقًا لا في الافتتاحي ولا في الجدول ===\n");
{
  const w = acc("acc_w3", "محفظة", "pot", 0);
  const entries: JournalEntry[] = [
    recordIncome(salary, w, 20000, "2026-08-01", "p1"),
    recordIncome(salary, w, 99999, "2026-10-01", "p3"),
  ];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries, fromDate: "2026-08-01", toDate: "2026-08-31" });
  assertEqual(report.rows.length, 1, "3-أ: سطر واحد فقط (حركة أغسطس)، حركة أكتوبر مستبعدة تمامًا");
  assertEqual(num(report.totals!["الرصيد الافتتاحي"]), 0, "3-ب: الرصيد الافتتاحي = 0 (لا حركات سابقة لـ2026-08-01)");
  assertEqual(num(report.totals!["الرصيد النهائي"]), 20000, "3-ج: الرصيد النهائي = 20,000 فقط — حركة أكتوبر لم تُضَف");
}

console.log("\n=== 4) إجمالي المدين والدائن وقت استخدام fromDate يقتصران على حركات الفترة فقط ===\n");
{
  const w = acc("acc_w4", "محفظة", "pot", 0);
  const entries: JournalEntry[] = [
    recordIncome(salary, w, 50000, "2026-08-01", "p1"),
    recordIncome(salary, w, 7000, "2026-09-05", "p2"),
    recordExpense(food, w, 3000, "2026-09-10", "p2", false, 57000),
  ];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries, fromDate: "2026-09-01" });
  assertEqual(num(report.totals!["إجمالي مدين"]), 7000, "4-أ: إجمالي مدين يقتصر على حركة سبتمبر (7,000) — لا يشمل أغسطس");
  assertEqual(num(report.totals!["إجمالي دائن"]), 3000, "4-ب: إجمالي دائن = 3,000 (مصروف سبتمبر فقط)");
}

console.log("\n=== 5) حساب بلا أي حركات ضمن الفترة (لكن له تاريخ سابق) — ليس خطأ، ويعرض الافتتاحي=النهائي ===\n");
{
  const w = acc("acc_w5", "محفظة", "pot", 0);
  const entries: JournalEntry[] = [recordIncome(salary, w, 15000, "2026-07-01", "p0")];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries, fromDate: "2026-09-01", toDate: "2026-09-30" });
  assertEqual(report.rows.length, 0, "5-أ: لا أسطر ضمن الفترة المحددة");
  assertEqual(num(report.totals!["الرصيد الافتتاحي"]), 15000, "5-ب: الرصيد الافتتاحي للفترة = 15,000 (أثر حركة يوليو المرحَّلة)");
  assertEqual(num(report.totals!["الرصيد النهائي"]), 15000, "5-ج: الرصيد النهائي = الافتتاحي نفسه (بلا حركات) = 15,000");
}

console.log("\n=== 6) عرض العملة: رمزها يظهر بجانب القيم المالية عند تمريرها، ولا يظهر إطلاقًا عند عدم تمريرها ===\n");
{
  const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
  const w = acc("acc_w6", "محفظة دولار", "pot", 1000);
  const entries: JournalEntry[] = [recordIncome(salary, w, 500, "2026-08-01", "p1")];

  const reportWithCurrency = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries, currency: usd });
  assertTrue(reportWithCurrency.totals!["الرصيد النهائي"].includes("$"), "6-أ: الرصيد النهائي يتضمَّن رمز العملة ($) عند تمرير currency");
  assertEqual(reportWithCurrency.totals!["العملة"], "دولار أمريكي ($)", "6-ب: مفتاح 'العملة' في totals يعرض الاسم والرمز بوضوح");
  assertTrue(reportWithCurrency.rows[1][3].includes("$") || reportWithCurrency.rows[1][4].includes("$"), "6-ج: عمود مدين/دائن للسطر يتضمَّن رمز العملة أيضًا");

  const reportNoCurrency = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries });
  assertTrue(!reportNoCurrency.totals!["الرصيد النهائي"].includes("$"), "6-د: بلا currency، لا يظهر أي رمز عملة — سلوك مطابق لما قبل هذه المرحلة تمامًا");
  assertEqual(reportNoCurrency.totals!["العملة"], undefined, "6-هـ: بلا currency، لا يوجد مفتاح 'العملة' في totals إطلاقًا");
}

console.log("\n=== 7) عمود operationNumber يظهر إن وُجد، و'—' إن لم يوجد ===\n");
{
  const w = acc("acc_w7", "محفظة", "pot", 0);
  const withNum = recordIncome(salary, w, 1000, "2026-08-01", "p1");
  withNum.operationNumber = "0042";
  const withoutNum = recordExpense(food, w, 200, "2026-08-02", "p1", false, 1000);
  const entries: JournalEntry[] = [withNum, withoutNum];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries });

  assertEqual(report.columns[1], "رقم العملية", "7-أ: عمود 'رقم العملية' موجود في columns (index 1)");
  assertEqual(report.rows[0][1], "0042", "7-ب: القيد الذي يملك operationNumber يعرضه كما هو (0042)");
  assertEqual(report.rows[1][1], "—", "7-ج: القيد بلا operationNumber يعرض '—' بدل قيمة فارغة أو خطأ");
}

console.log("\n=== 8) عمود 'البيان' يتضمَّن نوع العملية بالعربية، ومدين/دائن كعمودين منفصلين ===\n");
{
  const w = acc("acc_w8", "محفظة", "pot", 0);
  const entries: JournalEntry[] = [
    recordIncome(salary, w, 1000, "2026-08-01", "p1"),
    recordExpense(food, w, 300, "2026-08-02", "p1", false, 1000),
  ];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries });
  assertTrue(report.rows[0][2].includes("دخل"), "8-أ: بيان عملية الدخل يتضمَّن نوعها بالعربية 'دخل'");
  assertTrue(report.rows[1][2].includes("مصروف"), "8-ب: بيان عملية المصروف يتضمَّن نوعها بالعربية 'مصروف'");
  assertTrue(report.rows[0][4] !== "—" && report.rows[0][3] === "—", "8-ج: سطر الدخل (مدين للمحفظة) يملأ عمود 'مدين' فقط");
  assertTrue(report.rows[1][3] !== "—" && report.rows[1][4] === "—", "8-د: سطر المصروف (دائن للمحفظة) يملأ عمود 'دائن' فقط");
}

console.log("\n=== 9) العنوان يتضمَّن كود الحساب عند وجوده ===\n");
{
  const w: Account = { id: "acc_w9", name: "محفظة مُرقَّمة", category: "pot", openingBalance: 0, status: "active", code: "2005" };
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries: [] });
  assertTrue(report.title.includes("2005"), "9-أ: عنوان التقرير يتضمَّن كود الحساب (2005) عند وجوده");
  assertTrue(report.title.includes("محفظة مُرقَّمة"), "9-ب: العنوان يتضمَّن اسم الحساب أيضًا كما كان دائمًا");
}

console.log("\n=== 10) تحويل بين أوعية يظهر بشكل صحيح في كشف حساب أحد الطرفين، مع الرصيد الافتتاحي الصحيح ===\n");
{
  const potA = acc("acc_potA", "وعاء أ", "pot", 2000);
  const potB = acc("acc_potB", "وعاء ب", "pot", 0);
  const entries: JournalEntry[] = [
    recordTransfer(potA, potB, 500, "2026-08-01", "p1"),
    recordTransfer(potA, potB, 300, "2026-09-01", "p2"),
  ];
  const report = buildAccountLedgerReport({ account: potA, allAccounts: [potA, potB], entries, fromDate: "2026-09-01" });
  assertEqual(num(report.totals!["الرصيد الافتتاحي"]), 1500, "10-أ: الرصيد الافتتاحي للفترة = 1,500 (2,000 - 500 من تحويل أغسطس المُرحَّل)");
  assertEqual(num(report.totals!["الرصيد النهائي"]), 1200, "10-ب: الرصيد النهائي = 1,500 - 300 = 1,200، يطابق computeBalance");
  assertEqual(num(report.totals!["الرصيد النهائي"]), computeBalance(potA, entries), "10-ج: يطابق computeBalance الحقيقية تمامًا");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات كشف الحساب (المرحلة 5، الخطوة 1): ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
