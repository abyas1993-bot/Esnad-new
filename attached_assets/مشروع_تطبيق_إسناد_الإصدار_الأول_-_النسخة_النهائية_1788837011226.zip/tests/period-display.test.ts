// ============================================================
// اختبارات الملاحظة 2 §1: تسمية عرض الفترات (src/periodDisplay.ts)
// دالة نقية بحتة — لا تخزين، لا شبكة. تغطي: شهر تقويمي كامل، نطاق مخصَّص، فترة يوم واحد،
// حالات حدّية (فبراير كبيسة/غير كبيسة، أشهر بأطوال مختلفة، نهاية/بداية سنة).
// ============================================================
import { formatPeriodLabel } from "../src/periodDisplay";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  if (actual === expected) {
    passed++;
    console.log(`✅ ${label}`);
  } else {
    failed++;
    console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`);
  }
}

console.log("=== 1) شهر تقويمي كامل (المثال المذكور في المواصفة) ===\n");
assertEqual(formatPeriodLabel({ startDate: "2026-09-01", endDate: "2026-09-30" }), "سبتمبر 2026", "1-أ: سبتمبر 2026 (30 يومًا) → تسمية شهرية مختصرة");
assertEqual(formatPeriodLabel({ startDate: "2026-01-01", endDate: "2026-01-31" }), "يناير 2026", "1-ب: يناير (31 يومًا) → تسمية شهرية مختصرة");
assertEqual(formatPeriodLabel({ startDate: "2026-02-01", endDate: "2026-02-28" }), "فبراير 2026", "1-ج: فبراير غير كبيسة (28 يومًا) → تسمية شهرية مختصرة");
assertEqual(formatPeriodLabel({ startDate: "2028-02-01", endDate: "2028-02-29" }), "فبراير 2028", "1-د: فبراير كبيسة (29 يومًا) → تسمية شهرية مختصرة");
assertEqual(formatPeriodLabel({ startDate: "2026-12-01", endDate: "2026-12-31" }), "ديسمبر 2026", "1-هـ: ديسمبر (نهاية السنة) → تسمية شهرية مختصرة");

console.log("\n=== 2) نطاق زمني مخصَّص (ليس شهرًا كاملًا) — المثال المذكور في المواصفة ===\n");
assertEqual(formatPeriodLabel({ startDate: "2026-09-01", endDate: "2026-09-15" }), "01 سبتمبر 2026 – 15 سبتمبر 2026", "2-أ: نصف الشهر الأول → المدى الكامل بالتنسيق المطلوب");
assertEqual(formatPeriodLabel({ startDate: "2026-09-10", endDate: "2026-09-30" }), "10 سبتمبر 2026 – 30 سبتمبر 2026", "2-ب: نطاق لا يبدأ من اليوم الأول رغم انتهائه بآخر يوم → ليس شهرًا كاملًا");
assertEqual(formatPeriodLabel({ startDate: "2026-08-15", endDate: "2026-09-15" }), "15 أغسطس 2026 – 15 سبتمبر 2026", "2-ج: نطاق يمتد عبر شهرين مختلفين");
assertEqual(formatPeriodLabel({ startDate: "2026-12-20", endDate: "2027-01-10" }), "20 ديسمبر 2026 – 10 يناير 2027", "2-د: نطاق يعبر حدود السنة");

console.log("\n=== 3) فترة يوم واحد (كما تُنشئها الواجهة تلقائيًا عند أول تشغيل/بعد الإغلاق) ===\n");
assertEqual(formatPeriodLabel({ startDate: "2026-09-07", endDate: "2026-09-07" }), "07 سبتمبر 2026 – 07 سبتمبر 2026", "3-أ: بداية = نهاية (يوم واحد) وليس اليوم الأول من الشهر → يُعرض كمدى بنفس التاريخ مرتين");
assertEqual(formatPeriodLabel({ startDate: "2026-09-01", endDate: "2026-09-01" }), "01 سبتمبر 2026 – 01 سبتمبر 2026", "3-ب: يوم واحد يصادف اليوم الأول من الشهر (لكن ليس آخر يوم) → لا يُعامَل كشهر كامل");

console.log("\n=== 4) لا أثر على المعرّف الداخلي — الدالة لا تقرأه ولا تستخدمه إطلاقًا ===\n");
{
  const withId = formatPeriodLabel({ startDate: "2026-09-01", endDate: "2026-09-30", id: "period_1788734584673" } as any);
  assertEqual(withId, "سبتمبر 2026", "4-أ: وجود حقل id إضافي على الكائن المُمرَّر لا يغيّر الناتج — الدالة تعتمد فقط على startDate/endDate");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات تسمية عرض الفترات: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
