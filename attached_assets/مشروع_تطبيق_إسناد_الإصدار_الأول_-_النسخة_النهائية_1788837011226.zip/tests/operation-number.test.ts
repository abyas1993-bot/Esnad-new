// ============================================================
// اختبارات "رقم العملية الظاهر" (Operation Number) — المرحلة الثالثة.
// النظام كله عرضي بحت (لا Migration، لا تعديل على قيود محفوظة، لا رفع DB_VERSION) —
// انظر computeDisplayOperationNumbers في repository.ts. هذه الاختبارات تثبت:
// 1) الترقيم التسلسلي التلقائي للقيود الجديدة.
// 2) رفض التكرار.
// 3) القيود القديمة بلا operationNumber تحصل على رقم عرض مناسب دون أي كتابة إلى التخزين.
// 4) عدم المساس بـ id الداخلي أو بقاعدة "الإضافة فقط" الموثَّقة في storage.ts.
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { recordIncome, recordExpense } from "../src/transactions";
import { FileStorageAdapter } from "../src/storage";
import { Repository, computeDisplayOperationNumbers } from "../src/repository";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
async function assertRejects(fn: () => Promise<unknown> | unknown, label: string) {
  try {
    await fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يُرفَض ولم يُرفَض`);
  } catch {
    passed++; console.log(`✅ ${label}`);
  }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;
const DB_FILE = "/tmp/isnad_test_opnum_db.json";

async function main() {
  const fs = require("fs");

  console.log("=== 1) الرقم التالي المقترح تلقائيًا يبدأ من 0001 ويتسلسل ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);

    assertEqual(await repo.getNextOperationNumber(), "0001", "1-أ: أول رقم مقترح في قاعدة بيانات فارغة من القيود = 0001");

    const e1 = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
    e1.operationNumber = "0001";
    await repo.persistJournalEntry(e1);
    assertEqual(await repo.getNextOperationNumber(), "0002", "1-ب: بعد حفظ 0001 يصبح المقترح التالي 0002");

    const e2 = recordIncome(salary, wallet, 500, "2026-08-02", "p1");
    e2.operationNumber = "0002";
    await repo.persistJournalEntry(e2);
    assertEqual(await repo.getNextOperationNumber(), "0003", "1-ج: بعد حفظ 0002 يصبح المقترح التالي 0003");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 2) رفض تكرار رقم العملية ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);

    const e1 = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
    e1.operationNumber = "0007";
    await repo.persistJournalEntry(e1);

    assertTrue(await repo.isOperationNumberTaken("0007"), "2-أ: الرقم 0007 يُعتبَر مستخدَمًا بعد حفظ قيد به");
    assertTrue(!(await repo.isOperationNumberTaken("0099")), "2-ب: رقم لم يُستخدَم بعد (0099) لا يُعتبَر مأخوذًا");

    // محاكاة سلوك الواجهة: التحقق قبل الحفظ، ورفض القيد الثاني بنفس الرقم برسالة واضحة
    await assertRejects(async () => {
      if (await repo.isOperationNumberTaken("0007")) throw new Error("رقم العملية مستخدَم بالفعل.");
    }, "2-ج: محاولة استخدام رقم 0007 مرة أخرى تُرفَض قبل الحفظ");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 3) القيود القديمة بلا operationNumber تحصل على رقم عرض مناسب دون أي كتابة إلى التخزين ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    // نكتب دَمبًا يدويًا يحاكي بيانات ما قبل هذه المرحلة تمامًا: ثلاث قيود بلا operationNumber إطلاقًا.
    const legacyDump = {
      accounts: {
        acc_wallet: { id: "acc_wallet", name: "المحفظة", category: "pot", openingBalance: 0, status: "active" },
        acc_salary: { id: "acc_salary", name: "الراتب", category: "income_source", openingBalance: 0, status: "active" },
      },
      journalEntries: [
        { id: "je_1000_1_aaa", entryDate: "2026-07-01", transactionType: "income", periodId: "p0", lines: [{ accountId: "acc_wallet", direction: "DEBIT", amount: 100 }, { accountId: "acc_salary", direction: "CREDIT", amount: 100 }] },
        { id: "je_1000_2_bbb", entryDate: "2026-07-05", transactionType: "income", periodId: "p0", lines: [{ accountId: "acc_wallet", direction: "DEBIT", amount: 200 }, { accountId: "acc_salary", direction: "CREDIT", amount: 200 }] },
        { id: "je_1000_3_ccc", entryDate: "2026-07-03", transactionType: "income", periodId: "p0", lines: [{ accountId: "acc_wallet", direction: "DEBIT", amount: 300 }, { accountId: "acc_salary", direction: "CREDIT", amount: 300 }] },
      ],
      periods: {}, periodCloseResults: {}, planningSettings: {}, currencies: {}, accountCurrencyLinks: {},
      // ملاحظة: عمدًا بلا operationNumber على أي قيد — هذا هو الاختبار (بيانات ما قبل المرحلة 3).
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(legacyDump, null, 2), "utf-8");

    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const rawBefore = fs.readFileSync(DB_FILE, "utf-8");
    const withNumbers = await repo.getAllJournalEntriesWithDisplayNumbers();
    assertEqual(withNumbers.length, 3, "3-أ: القيود القديمة الثلاثة عادت كاملة بعد إضافة نظام الترقيم");

    // كلها بلا رقم صريح → تُرتَّب بترتيب زمني مستقر (بالتاريخ) وتُمنَح 0001/0002/0003 بحسب هذا الترتيب
    const byId = new Map(withNumbers.map((e) => [e.id, e.displayOperationNumber]));
    assertEqual(byId.get("je_1000_1_aaa"), "0001", "3-ب: أقدم قيد (2026-07-01) يحصل على رقم العرض 0001");
    assertEqual(byId.get("je_1000_3_ccc"), "0002", "3-ج: القيد الأوسط تاريخيًا (2026-07-03) يحصل على 0002");
    assertEqual(byId.get("je_1000_2_bbb"), "0003", "3-د: الأحدث تاريخيًا (2026-07-05) يحصل على 0003");

    // الأهم: لم يُكتَب أي شيء إلى الملف — القراءة وحدها لا تُعدِّل التخزين إطلاقًا
    const rawAfter = fs.readFileSync(DB_FILE, "utf-8");
    assertEqual(rawAfter, rawBefore, "3-هـ: ملف التخزين لم يتغيّر بايتًا واحدًا بعد قراءة أرقام العرض (لا Migration ولا كتابة فعلية)");

    // ونفس القيود لا تزال بلا operationNumber صريح في التخزين الفعلي (getAllJournalEntries الخام)
    const raw = await repo.getAllJournalEntries();
    assertTrue(raw.every((e) => e.operationNumber === undefined), "3-و: لا قيد قديم اكتسب operationNumber صريحًا في التخزين — الرقم عرضي بحت");

    // رقم مقترح لقيد جديد يكمل بعد آخر رقم عرض محسوب (0003) → 0004
    assertEqual(await repo.getNextOperationNumber(), "0004", "3-ز: الرقم المقترح لعملية جديدة يكمل بعد آخر رقم عرض افتراضي (0004)");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 4) مزيج: قيود قديمة بلا رقم + قيود جديدة بأرقام صريحة — لا تعارض ولا تكرار ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);

    // قيد قديم الطراز بلا operationNumber (نضيفه مباشرة عبر الدوال الأصلية بلا تعيين الحقل)
    const legacy = recordIncome(salary, wallet, 100, "2026-06-01", "p0");
    await repo.persistJournalEntry(legacy); // بلا operationNumber — يحاكي قيدًا محفوظًا قبل هذه المرحلة

    // قيد جديد صريح الرقم
    const modern = recordExpense(acc("acc_food", "طعام", "expense"), wallet, 50, "2026-08-01", "p1", true);
    modern.operationNumber = "0050";
    await repo.saveAccount(acc("acc_food", "طعام", "expense"));
    await repo.persistJournalEntry(modern);

    const map = computeDisplayOperationNumbers(await repo.getAllJournalEntries());
    assertEqual(map.get(modern.id), "0050", "4-أ: القيد الحديث يحتفظ برقمه الصريح 0050 كما هو");
    assertEqual(map.get(legacy.id), "0051", "4-ب: القيد القديم (بلا رقم) يحصل على رقم عرض يكمل بعد أعلى رقم صريح موجود (0051)، لا يتصادم معه");

    // القيمتان فريدتان في نفس المجموعة
    const values = Array.from(map.values());
    assertEqual(new Set(values).size, values.length, "4-ج: كل أرقام العرض في هذه المجموعة فريدة، بلا أي تكرار");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات رقم العملية: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات رقم العملية:", e);
  process.exit(1);
});
