import { Account } from "../src/types";
import { closePeriod, applyCarriedForward, PeriodAccountActual } from "../src/period";
import { runDistribution } from "../src/distribution";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}
function round2(n: number): number { return Math.round((n + Number.EPSILON) * 100) / 100; }

const food = acc("exp_food", "طعام", "expense");
const goalCar = acc("goal_car", "هدف السيارة", "goal");
const goalPhone = acc("goal_phone", "هدف الجوال", "goal");
const debtOnce = acc("debt_once", "دين لمرة واحدة", "one_time_debt");

console.log("=== إغلاق 1: فائض مصروف بلا التزام مؤجل → يصبح مالًا حرًا فورًا ===\n");
{
  const items: PeriodAccountActual[] = [{ account: food, approvedAmount: 10000, actualAmount: 7000, hasPendingObligation: false }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.freeCarriedSurplus, 3000, "إغلاق1: الفائض (3,000) يتحرر كمال حر فورًا");
  assertEqual(r.summaryLines[0].releasedAsFreeCash, true, "إغلاق1: السطر التاريخي يوثّق التحرير الفعلي");
  assertEqual(r.expensesCarriedDeficit[food.id], undefined, "إغلاق1: لا يوجد عجز مرحّل لهذا الحساب");
}

console.log("\n=== إغلاق 2: فائض مصروف مع وجود التزام مؤجل مرتبط به → لا يتحرر هذه الدورة ===\n");
{
  const items: PeriodAccountActual[] = [{ account: food, approvedAmount: 10000, actualAmount: 7000, hasPendingObligation: true }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.freeCarriedSurplus, 0, "إغلاق2: الفائض لا يتحرر بسبب التزام مؤجل مرتبط بالحساب");
  assertEqual(r.summaryLines[0].releasedAsFreeCash, false, "إغلاق2: السطر التاريخي يوثّق عدم التحرير مع توضيح السبب");
  assertTrue(r.summaryLines[0].explanation.includes("معلّق") || r.summaryLines[0].explanation.length > 0, "إغلاق2: التفسير موجود ويوثّق حالة التعليق");
}

console.log("\n=== إغلاق 3: تجاوز مصروف → عجز مرحّل يرفع الحد الأدنى الفعلي للفترة القادمة ===\n");
{
  const items: PeriodAccountActual[] = [{ account: food, approvedAmount: 10000, actualAmount: 12500 }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.expensesCarriedDeficit[food.id], 2500, "إغلاق3: عجز 2,500 مسجَّل لحساب الطعام تحديدًا");
  assertEqual(r.freeCarriedSurplus, 0, "إغلاق3: لا فائض حر — التجاوز ليس فائضًا بأي حال");

  // تكامل كامل: تشغيل الفترة القادمة فعليًا والتحقق أن الحد الأدنى الفعلي أصبح 12,500 وليس 10,000
  const merged = applyCarriedForward(r, {
    incomeAvailable: 12500,
    expenses: [{ account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high" }],
    goals: [],
    oneTimeDebts: [],
    recurringDebts: [],
  });
  const nextRun = runDistribution(merged);
  // وفق المواصفة v3 (§4/§6): العجز المرحّل سطر منفصل في Stage 0، والحد الأدنى الأصلي سطر منفصل في Stage 1 — لا دمج صامت
  const foodStage0 = nextRun.allocations.find((a) => a.accountId === food.id && a.stage === 0);
  const foodStage1 = nextRun.allocations.find((a) => a.accountId === food.id && a.stage === 1);
  assertEqual(foodStage0?.amount, 2500, "إغلاق3-تكامل: التجاوز المرحّل (2,500) سطر مستقل في Stage 0 — لا يُدمَج صامتًا");
  assertEqual(foodStage1?.amount, 10000, "إغلاق3-تكامل: الحد الأدنى الأصلي (10,000) سطر مستقل في Stage 1");
  assertEqual(round2((foodStage0?.amount || 0) + (foodStage1?.amount || 0)), 12500, "إغلاق3-تكامل: المجموع الكلي المموَّل للطعام = 12,500 (2,500+10,000) عبر سطرين منفصلين وليس سطرًا واحدًا مدموجًا");
}

console.log("\n=== إغلاق 4: عجز هدف (تمويل ناقص) → يُموَّل بأولوية قصوى في Stage 0 للفترة القادمة ===\n");
{
  const items: PeriodAccountActual[] = [{ account: goalCar, approvedAmount: 10000, actualAmount: 6000 }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.goalsCarriedDeficit[goalCar.id], 4000, "إغلاق4: عجز 4,000 مسجَّل للهدف");

  const merged = applyCarriedForward(r, {
    incomeAvailable: 4000,
    expenses: [],
    goals: [{ account: goalCar, minAllocation: 5000, maxAllocation: 10000, targetAmount: 100000, achievedAmount: 6000, priority: "moderate" }],
    oneTimeDebts: [],
    recurringDebts: [],
  });
  const nextRun = runDistribution(merged);
  const stage0 = nextRun.allocations.find((a) => a.accountId === goalCar.id && a.stage === 0);
  assertEqual(stage0?.amount, 4000, "إغلاق4-تكامل: العجز المرحّل (4,000) يُموَّل بالكامل في Stage 0 قبل أي شيء آخر رغم أن أولوية الهدف نفسه منخفضة (moderate)");
}

console.log("\n=== إغلاق 5: فائض هدف (تمويل زائد) → يخفّض الاحتياج الفعلي في الفترة القادمة (لا يُضاف كدخل عام) ===\n");
{
  const items: PeriodAccountActual[] = [{ account: goalPhone, approvedAmount: 5000, actualAmount: 8000 }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.goalsCarriedSurplus[goalPhone.id], 3000, "إغلاق5: فائض 3,000 مسجَّل للهدف");

  const merged = applyCarriedForward(r, {
    incomeAvailable: 33000 + 5000, // حدود دنيا وهمية صفرية هنا (لا مصروفات) + مبلغ للهدف
    expenses: [],
    goals: [{ account: goalPhone, minAllocation: 5000, maxAllocation: 20000, targetAmount: 100000, achievedAmount: 8000, priority: "critical" }],
    oneTimeDebts: [],
    recurringDebts: [],
  });
  const nextRun = runDistribution(merged);
  const stage2 = nextRun.allocations.find((a) => a.accountId === goalPhone.id && a.stage === 2);
  assertEqual(stage2?.amount, 2000, "إغلاق5-تكامل: الحد الأدنى (5,000) مخفَّضًا بمقدار الفائض المرحّل (3,000) = 2,000 فقط يُخصَّص فعليًا");
}

console.log("\n=== إغلاق 6: عجز سداد دين لمرة واحدة → يُموَّل بأولوية قصوى Stage 0 للفترة القادمة ===\n");
{
  const items: PeriodAccountActual[] = [{ account: debtOnce, approvedAmount: 6000, actualAmount: 2000 }];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.oneTimeDebtsCarriedDeficit[debtOnce.id], 4000, "إغلاق6: عجز سداد 4,000 مسجَّل للدين");

  const merged = applyCarriedForward(r, {
    incomeAvailable: 4000,
    expenses: [],
    goals: [],
    oneTimeDebts: [{ account: debtOnce, remainingBalance: 4000, priority: "urgent_moderate" }],
    recurringDebts: [],
  });
  const nextRun = runDistribution(merged);
  const stage0 = nextRun.allocations.find((a) => a.accountId === debtOnce.id && a.stage === 0);
  assertEqual(stage0?.amount, 4000, "إغلاق6-تكامل: العجز المرحّل (4,000) يُموَّل في Stage 0 رغم أن أولوية الدين نفسه منخفضة (urgent_moderate)");
}

console.log("\n=== إغلاق 7: السجل التاريخي دائم ولا يُفقَد أي فرق أو يُدمَج في رقم عام مجهول ===\n");
{
  const items: PeriodAccountActual[] = [
    { account: food, approvedAmount: 10000, actualAmount: 7000 }, // فائض
    { account: goalCar, approvedAmount: 10000, actualAmount: 6000 }, // عجز
    { account: goalPhone, approvedAmount: 5000, actualAmount: 5000 }, // مطابق تمامًا
  ];
  const r = closePeriod("p1", "p2", items);
  assertEqual(r.summaryLines.length, 3, "إغلاق7: كل حساب له سطر مستقل في السجل — لا دمج");
  const byId = Object.fromEntries(r.summaryLines.map((l) => [l.accountId, l]));
  assertEqual(byId[food.id].varianceType, "surplus", "إغلاق7: نوع فرق الطعام موثَّق بدقة = فائض");
  assertEqual(byId[goalCar.id].varianceType, "deficit", "إغلاق7: نوع فرق الهدف موثَّق بدقة = عجز");
  assertEqual(byId[goalPhone.id].varianceType, "none", "إغلاق7: التطابق التام موثَّق بدقة = لا فرق");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات إغلاق الشهر: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
