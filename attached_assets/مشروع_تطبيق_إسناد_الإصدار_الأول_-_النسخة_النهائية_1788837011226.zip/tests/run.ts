import { Account, JournalEntry } from "../src/types";
import { computeBalance, UnbalancedEntryError, createJournalEntry } from "../src/ledger";
import {
  recordIncome,
  recordExpense,
  recordRecurringDebtPayment,
} from "../src/transactions";
import { computeVariance } from "../src/variance";

let passed = 0;
let failed = 0;

function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    passed++;
    console.log(`✅ ${label}`);
  } else {
    failed++;
    console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`);
  }
}

function assertThrows(fn: () => void, errType: Function, label: string) {
  try {
    fn();
    failed++;
    console.log(`❌ ${label} — كان يجب أن يرمي خطأ ولم يفعل`);
  } catch (e) {
    if (e instanceof errType) {
      passed++;
      console.log(`✅ ${label}`);
    } else {
      failed++;
      console.log(`❌ ${label} — رمى خطأ من نوع خاطئ: ${(e as Error).message}`);
    }
  }
}

console.log("=== قسم 1: اختبارات القيد المزدوج الأساسية (من مواصفة المستخدم §40) ===\n");

const wallet: Account = { id: "acc_wallet", name: "المحفظة", category: "pot", openingBalance: 0, status: "active" };
const salary: Account = { id: "acc_salary", name: "الراتب", category: "income_source", openingBalance: 0, status: "active" };
const food: Account = { id: "acc_food", name: "الطعام", category: "expense", openingBalance: 0, status: "active" };
const debt: Account = { id: "acc_debt", name: "بطاقة ائتمان", category: "recurring_debt", openingBalance: 0, status: "active" };

const entries: JournalEntry[] = [];

// اختبار 1: إضافة وعاء بقيمة 100,000 (رصيد افتتاحي)
const wallet100k: Account = { ...wallet, openingBalance: 100000 };
assertEqual(computeBalance(wallet100k, []), 100000, "اختبار 1: وعاء برصيد افتتاحي 100,000 → الرصيد = 100,000");

// اختبار 2: إضافة دخل 50,000 إلى الوعاء
const walletZero: Account = { ...wallet, openingBalance: 0 };
const e1 = recordIncome(salary, walletZero, 50000, "2026-08-01", "p1");
entries.push(e1);
assertEqual(computeBalance(walletZero, entries), 50000, "اختبار 2: دخل 50,000 → رصيد الوعاء = 50,000");
assertEqual(computeBalance(salary, entries), 50000, "اختبار 2ب: حساب الدخل (دائن) = 50,000");

// اختبار 3: مصروف 10,000
const e2 = recordExpense(food, walletZero, 10000, "2026-08-02", "p1", false, computeBalance(walletZero, entries));
entries.push(e2);
assertEqual(computeBalance(walletZero, entries), 40000, "اختبار 3: بعد مصروف 10,000 → رصيد الوعاء = 40,000");
assertEqual(computeBalance(food, entries), 10000, "اختبار 3ب: حساب المصروف (مدين) = 10,000");

// اختبار 4: إنشاء دين 20,000 (بدون دفع) — قيد مباشر متوازن
const e3 = createJournalEntry({
  id: "je_debt_create",
  entryDate: "2026-08-03",
  transactionType: "debt_creation",
  periodId: "p1",
  lines: [
    { accountId: food.id, direction: "DEBIT", amount: 20000 },
    { accountId: debt.id, direction: "CREDIT", amount: 20000 },
  ],
});
entries.push(e3);
assertEqual(computeBalance(debt, entries), 20000, "اختبار 4: إنشاء دين 20,000 → الالتزام = 20,000");

// اختبار 5: سداد 5,000
const e4 = recordRecurringDebtPayment(debt, walletZero, 5000, "2026-08-04", "p1");
entries.push(e4);
assertEqual(computeBalance(debt, entries), 15000, "اختبار 5: بعد سداد 5,000 → المتبقي = 15,000");

// اختبار: منع قيد غير متوازن
assertThrows(
  () =>
    createJournalEntry({
      id: "je_bad",
      entryDate: "2026-08-05",
      transactionType: "correction",
      periodId: "p1",
      lines: [
        { accountId: walletZero.id, direction: "DEBIT", amount: 100 },
        { accountId: food.id, direction: "CREDIT", amount: 99 },
      ],
    }),
  UnbalancedEntryError,
  "اختبار توازن: قيد بمدين 100 ودائن 99 → يُرفض"
);

// اختبار: منع سداد أكثر من رصيد الوعاء (بدون تفعيل السماح بالسالب)
assertThrows(
  () => recordExpense(food, walletZero, 999999, "2026-08-06", "p1", false, computeBalance(walletZero, entries)),
  Error,
  "اختبار: مصروف أكبر من رصيد الوعاء دون سماح بالسالب → يُرفض"
);

console.log("\n=== قسم 2: الحالات الخمس لمحرك الفروقات المرحّلة (§11 المعتمدة) ===\n");

// حالة 1: مصروف مخصص 10,000 فعلي 7,000 → فائض 3,000 (معلّق قبل الإغلاق)
const foodAcc: Account = { id: "acc_food2", name: "طعام", category: "expense", openingBalance: 0, status: "active" };
const v1 = computeVariance(foodAcc, 10000, 7000, false);
assertEqual(
  { type: v1.varianceType, amount: v1.variance, pending: v1.pendingPeriodClose },
  { type: "surplus", amount: 3000, pending: true },
  "حالة 1: مصروف معتمد=10,000 فعلي=7,000 → فائض 3,000 (معلَّق قبل إغلاق الدورة)"
);

// حالة 2: مصروف مخصص 10,000 فعلي 12,500 → تجاوز/عجز 2,500
const v2 = computeVariance(foodAcc, 10000, 12500, false);
assertEqual(
  { type: v2.varianceType, amount: v2.variance },
  { type: "deficit", amount: 2500 },
  "حالة 2: مصروف معتمد=10,000 فعلي=12,500 → تجاوز/عجز 2,500 (ليس فائضًا بأي حال)"
);

// حالة 3: هدف مخصص 10,000 فعلي 7,000 → عجز/احتياج مرحّل 3,000
const goalAcc: Account = { id: "acc_goal1", name: "هدف السيارة", category: "goal", openingBalance: 0, status: "active" };
const v3 = computeVariance(goalAcc, 10000, 7000);
assertEqual(
  { type: v3.varianceType, amount: v3.variance },
  { type: "deficit", amount: 3000 },
  "حالة 3: هدف معتمد=10,000 فعلي=7,000 → عجز/احتياج مرحّل 3,000"
);

// حالة 4: هدف مخصص 10,000 فعلي 12,500 → فائض 2,500
const v4 = computeVariance(goalAcc, 10000, 12500);
assertEqual(
  { type: v4.varianceType, amount: v4.variance },
  { type: "surplus", amount: 2500 },
  "حالة 4: هدف معتمد=10,000 فعلي=12,500 → فائض 2,500"
);

// حالة 5: دين مستمر — مخصص سداد 5,000، فعلي سداد 9,000 (دخل فائض وُجِّه إضافيًا)
const debtAcc: Account = {
  id: "acc_debt2",
  name: "بطاقة ائتمان",
  category: "recurring_debt",
  openingBalance: 0,
  status: "active",
  meta: { minLimit: 10000, maxLimit: 50000 },
};
const v5 = computeVariance(debtAcc, 5000, 9000);
assertEqual(
  { type: v5.varianceType, amount: v5.variance },
  { type: "surplus", amount: 4000 },
  "حالة 5: دين مستمر معتمد سداد=5,000 فعلي=9,000 → فائض سداد 4,000 (يُخفِّض الالتزام، لا يصبح مالًا حرًا)"
);
// التحقق من أن رصيد الدين الفعلي بعد السداد الحقيقي = 42,000 - 9,000 = 33,000
const debtWithBalance: Account = { ...debtAcc, openingBalance: 42000 };
const debtEntries: JournalEntry[] = [recordRecurringDebtPayment(debtAcc, walletZero, 9000, "2026-08-10", "p1")];
assertEqual(
  computeBalance(debtWithBalance, debtEntries),
  33000,
  "حالة 5ب: الرصيد الفعلي للدين المستمر بعد سداد 9,000 من أصل 42,000 = 33,000"
);

console.log(`\n=== النتيجة النهائية: ${passed} ناجح، ${failed} فاشل ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
