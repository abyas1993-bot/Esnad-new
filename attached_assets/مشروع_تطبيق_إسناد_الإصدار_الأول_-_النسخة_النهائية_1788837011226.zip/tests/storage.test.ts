import { Account } from "../src/types";
import { computeBalance } from "../src/ledger";
import { recordIncome, recordExpense, recordRecurringDebtPayment } from "../src/transactions";
import { FileStorageAdapter, UnbalancedPersistAttemptError } from "../src/storage";
import { Repository } from "../src/repository";
import { DistributionInput } from "../src/distribution";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
async function assertRejects(fn: () => Promise<unknown>, errType: Function, label: string) {
  try {
    await fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يُرفَض ولم يُرفَض`);
  } catch (e) {
    if (e instanceof errType) { passed++; console.log(`✅ ${label}`); }
    else { failed++; console.log(`❌ ${label} — رُفض بخطأ من نوع خاطئ: ${(e as Error).message}`); }
  }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;

const DB_FILE = "/tmp/isnad_test_db.json";

async function main() {
  const fs = require("fs");
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);

  console.log("=== 1) الاستمرارية عبر \"إعادة تشغيل\" فعلية (نسخة Node جديدة تقرأ نفس الملف) ===\n");
  {
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    const food = acc("acc_food", "طعام", "expense");

    // --- الجلسة 1: إنشاء البيانات وحفظها ---
    const storage1 = new FileStorageAdapter(DB_FILE);
    const repo1 = new Repository(storage1);
    await repo1.saveAccount(wallet);
    await repo1.saveAccount(salary);
    await repo1.saveAccount(food);
    const e1 = recordIncome(salary, wallet, 50000, "2026-08-01", "p1");
    await repo1.persistJournalEntry(e1);
    const e2 = recordExpense(food, wallet, 12000, "2026-08-02", "p1", false, await repo1.getAccountBalance(wallet.id));
    await repo1.persistJournalEntry(e2);
    const balanceBeforeRestart = await repo1.getAccountBalance(wallet.id);
    assertEqual(balanceBeforeRestart, 38000, "1-أ: الرصيد قبل \"إعادة التشغيل\" = 38,000 (50,000-12,000)");

    // --- محاكاة إغلاق التطبيق: لا نحتفظ بأي مرجع للكائنات أعلاه ---

    // --- الجلسة 2: عملية Node جديدة منطقيًا (كائنات جديدة تمامًا) تقرأ نفس الملف من القرص ---
    const storage2 = new FileStorageAdapter(DB_FILE);
    const repo2 = new Repository(storage2);
    const reloadedAccounts = await repo2.getAllAccounts();
    const reloadedEntries = await repo2.getAllJournalEntries();
    assertEqual(reloadedAccounts.length, 3, "1-ب: كل الحسابات الثلاثة عادت من القرص بعد \"إعادة التشغيل\"");
    assertEqual(reloadedEntries.length, 2, "1-ج: كلا القيدين عادا من القرص");
    const balanceAfterRestart = await repo2.getAccountBalance(wallet.id);
    assertEqual(balanceAfterRestart, 38000, "1-د: نفس الرصيد بالضبط (38,000) محسوبًا من القيود المُعادة تحميلها من القرص — لا فقدان بيانات");
  }

  console.log("\n=== 2) منع كتابة قيد غير متوازن حتى عند استدعاء التخزين مباشرة (طبقة حماية مضاعفة) ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    await assertRejects(
      () => storage.appendJournalEntry({
        id: "bad_entry", entryDate: "2026-08-03", transactionType: "correction", periodId: "p1",
        lines: [
          { accountId: "acc_wallet", direction: "DEBIT", amount: 100 },
          { accountId: "acc_food", direction: "CREDIT", amount: 50 },
        ],
      }),
      UnbalancedPersistAttemptError,
      "2-أ: قيد بمدين 100 ودائن 50 يُرفَض عند التخزين المباشر، حتى بدون المرور عبر ledger.ts"
    );
  }

  console.log("\n=== 3) منع الكتابة فوق قيد بنفس المعرّف (لا تعديل رجعي للتاريخ) ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const dup = { id: "acc_wallet_income_dup", entryDate: "2026-08-01", transactionType: "correction" as const, periodId: "p1",
      lines: [{ accountId: "acc_food", direction: "DEBIT" as const, amount: 100 }, { accountId: "acc_salary", direction: "CREDIT" as const, amount: 100 }] };
    await storage.appendJournalEntry(dup);
    await assertRejects(() => storage.appendJournalEntry(dup), Error, "3-أ: محاولة حفظ نفس معرّف القيد مرتين تُرفَض");
  }

  console.log("\n=== 4) التكامل الكامل: محرك التوزيع يعمل على حسابات محمَّلة من التخزين ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const foodAcc = acc("acc_food", "طعام", "expense"); // نفس الحساب المخزَّن مسبقًا
    const input: DistributionInput = {
      periodId: "p1",
      incomeAvailable: 20000,
      expenses: [{ account: foodAcc, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high" }],
      goals: [], oneTimeDebts: [], recurringDebts: [],
    };
    // نتأكد فقط أن runDistributionPreview تستدعي المحرك الأصلي دون أي وسيط يغيّر نتيجته
    const result = repo.runDistributionPreview(input);
    assertEqual(result.allocations.find((a) => a.accountId === foodAcc.id && a.stage === 1)?.amount, 10000, "4-أ: محرك التوزيع (عبر المستودع) ينتج نفس نتيجة المحرك الأصلي تمامًا");
    // Planned لا يُخزَّن أبدًا تلقائيًا كأنه Actual — نتحقق أن رصيد الوعاء الحقيقي لم يتأثر بهذا التشغيل
    const balanceAfterPlanning = await repo.getAccountBalance("acc_wallet");
    assertEqual(balanceAfterPlanning, 38000, "4-ب: رصيد الوعاء الفعلي لم يتغيّر إطلاقًا بتشغيل محرك التوزيع (Planned لا يُخزَّن كـActual)");
  }

  console.log("\n=== 5) دورة إغلاق شهر كاملة عبر المستودع، ثم استمرارية النتيجة عبر \"إعادة تشغيل\" ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.openPeriod({ id: "p1", startDate: "2026-08-01", endDate: "2026-08-31", status: "open" });
    const foodAcc = acc("acc_food", "طعام", "expense");

    const closeResult = await repo.closePeriodAndPersist(
      "p1", "p2",
      [{ account: foodAcc, approvedAmount: 10000, actualAmount: 12000 }],
      { startDate: "2026-09-01", endDate: "2026-09-30" }
    );
    assertEqual(closeResult.expensesCarriedDeficit[foodAcc.id], 2000, "5-أ: عجز 2,000 محسوب فعليًا عبر period.ts دون أي تعديل عليها");

    const p1After = await repo.getPeriod("p1");
    const p2After = await repo.getPeriod("p2");
    assertEqual(p1After?.status, "closed", "5-ب: الفترة p1 أصبحت مغلقة");
    assertEqual(p2After?.status, "open", "5-ج: الفترة p2 فُتحت تلقائيًا");

    await assertRejects(
      () => repo.closePeriodAndPersist("p1", "p3", [], { startDate: "x", endDate: "y" }),
      Error,
      "5-د: لا يجوز إغلاق فترة مغلقة بالفعل مرة أخرى (سجل تاريخي دائم لا يُعاد حسابه)"
    );

    // --- "إعادة تشغيل" ---
    const storage2 = new FileStorageAdapter(DB_FILE);
    const repo2 = new Repository(storage2);
    const reloadedClose = await repo2.getPeriodCloseResult("p1");
    assertEqual(reloadedClose?.expensesCarriedDeficit[foodAcc.id], 2000, "5-هـ: سجل الإغلاق التاريخي عاد كاملًا من القرص بعد \"إعادة التشغيل\" — لا فقدان");
    const reloadedP2 = await repo2.getPeriod("p2");
    assertEqual(reloadedP2?.status, "open", "5-و: حالة الفترة p2 (مفتوحة) عادت صحيحة من القرص");
  }

  console.log("\n=== 6) عمليات سداد دين مستمر متعددة عبر جلسات مختلفة — الرصيد يبقى متسقًا محاسبيًا ===\n");
  {
    const debt = acc("acc_debt", "دين مستمر", "recurring_debt");
    const storageA = new FileStorageAdapter(DB_FILE);
    const repoA = new Repository(storageA);
    await repoA.saveAccount(debt);
    const eCreate = { id: "je_debt_create", entryDate: "2026-08-05", transactionType: "debt_creation" as const, periodId: "p2",
      lines: [{ accountId: "acc_food", direction: "DEBIT" as const, amount: 30000 }, { accountId: "acc_debt", direction: "CREDIT" as const, amount: 30000 }] };
    await repoA.persistJournalEntry(eCreate);

    const storageB = new FileStorageAdapter(DB_FILE); // جلسة/عملية مختلفة تمامًا
    const repoB = new Repository(storageB);
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const eDebtPay = recordRecurringDebtPayment(debt, wallet, 9000, "2026-08-06", "p2");
    await repoB.persistJournalEntry(eDebtPay);

    const storageC = new FileStorageAdapter(DB_FILE); // جلسة ثالثة تقرأ الناتج التراكمي
    const repoC = new Repository(storageC);
    const finalBalance = await repoC.getAccountBalance("acc_debt");
    assertEqual(finalBalance, 21000, "6-أ: الرصيد النهائي (30,000-9,000=21,000) صحيح رغم أن القيدين كُتبا من \"جلستين\" مختلفتين تمامًا لنفس الملف");
  }

  console.log("\n=== 7) الترحيل الفعلي: getCarriedForwardForPeriod + buildDistributionInput يستخدمان applyCarriedForward حقًا ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const foodAcc = acc("acc_food", "طعام", "expense");

    // 7-أ: سيناريو "غير موجود" — فترة بلا أي سجل إغلاق سابق يفتحها (أول فترة إطلاقًا)
    const noCarry = await repo.getCarriedForwardForPeriod("period_never_existed_xyz");
    assertEqual(noCarry, null, "7-أ: لا سجل ترحيل لفترة لم تُفتَح عبر إغلاق سابق — يعيد null بدل استثناء أو قيمة وهمية");

    // 7-ب: إغلاق فترة فعليًا بعجز مصروف (تجاوز)، ثم التحقق أن الفترة التالية تجده فعليًا
    await repo.openPeriod({ id: "p_carry_1", startDate: "2026-08-01", endDate: "2026-08-31", status: "open" });
    const closeResult = await repo.closePeriodAndPersist(
      "p_carry_1", "p_carry_2",
      [{ account: foodAcc, approvedAmount: 10000, actualAmount: 12500 }],
      { startDate: "2026-09-01", endDate: "2026-09-30" }
    );
    const found = await repo.getCarriedForwardForPeriod("p_carry_2");
    assertEqual(found?.closedPeriodId, "p_carry_1", "7-ب: البحث بمعرّف الفترة الجديدة (p_carry_2) يجد سجل إغلاق p_carry_1 فعليًا");
    assertEqual(found?.expensesCarriedDeficit[foodAcc.id], 2500, "7-ج: مقدار العجز المرحّل (2,500) صحيح من daftar القيود الحقيقي");

    // 7-د: buildDistributionInput لفترة p_carry_2 يُطبِّق الترحيل تلقائيًا (بلا أي إدخال يدوي إضافي)
    await repo.saveAccount(foodAcc);
    await repo.savePlanningSettings({ kind: "expense", accountId: foodAcc.id, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high" });
    const { input } = await repo.buildDistributionInput("p_carry_2", 2500);
    const foodInput = input.expenses.find((e) => e.account.id === foodAcc.id);
    assertEqual(foodInput?.carriedDeficit, 2500, "7-د: buildDistributionInput يملأ carriedDeficit=2,500 تلقائيًا من سجل الإغلاق — دون أي تمرير يدوي من الواجهة");

    const distResult = repo.runDistributionPreview(input);
    const stage0Alloc = distResult.allocations.find((a) => a.accountId === foodAcc.id && a.stage === 0);
    assertEqual(stage0Alloc?.amount, 2500, "7-هـ: runDistribution الفعلي يخصص 2,500 في Stage 0 لتغطية العجز المرحّل — إثبات أن الترحيل يُستخدَم فعليًا وليس شكليًا فقط");
  }


  console.log(`\n\n=== النتيجة الإجمالية لاختبارات طبقة التخزين: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  declare_process_exit(failed);
}

declare const process: { exit: (code: number) => void };
function declare_process_exit(failed: number) {
  if (failed > 0) process.exit(1);
}

main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات التخزين:", e);
  process.exit(1);
});
