// ============================================================
// اختبارات "سجل العمليات" — المرحلة الخامسة، الخطوة 2.
// buildTransactionLogReport دالة نقية بالكامل (بلا أي كتابة أو تعديل على البيانات) — تُبنى
// من entries جاهزة بالفعل مع displayOperationNumber (من computeDisplayOperationNumbers
// بالمرحلة 3، بلا حساب جديد هنا) وخريطة عملات محسوبة مسبقًا (من المرحلة 1).
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { recordIncome, recordExpense, recordTransfer, recordDirectEntry } from "../src/transactions";
import { computeDisplayOperationNumbers } from "../src/repository";
import { buildTransactionLogReport, TransactionLogEntry } from "../src/reports";
import { Currency, DEFAULT_CURRENCY } from "../src/currency";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}
/** يحاكي بالضبط ما يُرجعه Repository.getAllJournalEntriesWithDisplayNumbers دون أي كتابة فعلية. */
function withDisplayNumbers(entries: JournalEntry[]): TransactionLogEntry[] {
  const map = computeDisplayOperationNumbers(entries);
  return entries.map((e) => ({ ...e, displayOperationNumber: map.get(e.id)! }));
}

const wallet = acc("acc_wallet", "المحفظة", "pot");
const wallet2 = acc("acc_wallet2", "المحفظة الثانية", "pot");
const salary = acc("acc_salary", "الراتب", "income_source");
const food = acc("acc_food", "طعام", "expense");
const debt = acc("acc_debt", "دين", "recurring_debt");
const allAccounts = [wallet, wallet2, salary, food, debt];
const sarMap = new Map<string, Currency>(allAccounts.map((a) => [a.id, DEFAULT_CURRENCY]));

console.log("=== 1) عرض جميع العمليات بلا أي فلتر — كل شيء يظهر ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordExpense(food, wallet, 200, "2026-08-02", "p1", false, 1000),
    recordTransfer(wallet, wallet2, 100, "2026-08-03", "p1"),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap });
  assertEqual(report.rows.length, 3, "1-أ: كل العمليات الثلاث ظاهرة بلا فلتر");
  assertEqual(report.totals!["عدد العمليات"], "3", "1-ب: عدّاد العمليات في totals = 3");
}

console.log("\n=== 2) فلترة fromDate ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordIncome(salary, wallet, 2000, "2026-09-01", "p2"),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap, fromDate: "2026-09-01" });
  assertEqual(report.rows.length, 1, "2-أ: عملية واحدة فقط بعد fromDate");
  assertEqual(report.rows[0][1], "2026-09-01", "2-ب: تاريخ العملية الظاهرة صحيح");
}

console.log("\n=== 3) فلترة toDate ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordIncome(salary, wallet, 2000, "2026-09-01", "p2"),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap, toDate: "2026-08-31" });
  assertEqual(report.rows.length, 1, "3-أ: عملية واحدة فقط قبل toDate");
  assertEqual(report.rows[0][1], "2026-08-01", "3-ب: تاريخ العملية الظاهرة صحيح");
}

console.log("\n=== 4) فلترة نوع العملية ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordExpense(food, wallet, 200, "2026-08-02", "p1", false, 1000),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap, transactionType: "expense" });
  assertEqual(report.rows.length, 1, "4-أ: عملية واحدة فقط من نوع مصروف");
  assertEqual(report.rows[0][2], "مصروف", "4-ب: عمود 'البيان' يحتوي نوع العملية بالعربية (لا وصف إضافي هنا) = مصروف");
}

console.log("\n=== 5) فلترة الحساب (يظهر القيد إن ظهر الحساب مدينًا أو دائنًا) ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordExpense(food, wallet2, 200, "2026-08-02", "p1", true, 0),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap, accountId: wallet.id });
  assertEqual(report.rows.length, 1, "5-أ: عملية واحدة فقط تخص المحفظة الأولى");
  assertTrue(report.rows[0][3] === "المحفظة" || report.rows[0][4] === "المحفظة", "5-ب: المحفظة الأولى تظهر كطرف مدين أو دائن في السطر المُطابِق");
}

console.log("\n=== 6) فلترة العملة ===\n");
{
  const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
  const mixedMap = new Map<string, Currency>(allAccounts.map((a) => [a.id, DEFAULT_CURRENCY]));
  mixedMap.set(wallet2.id, usd);
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordTransfer(wallet2, wallet, 50, "2026-08-02", "p1"),
  ];
  const usdEntry = recordExpense(food, wallet2, 20, "2026-08-03", "p1", true, 0);
  entries.push(usdEntry);
  const { document: reportSar } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: mixedMap, currencyCode: "SAR" });
  const { document: reportUsd } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: mixedMap, currencyCode: "USD" });
  assertEqual(reportSar.rows.length, 2, "6-أ: فلترة SAR تعرض العمليتين اللتين مدينهما بالريال فقط");
  assertEqual(reportUsd.rows.length, 1, "6-ب: فلترة USD تعرض العملية الوحيدة التي مدينها بالدولار (wallet2) فقط");
}

console.log("\n=== 7) الترتيب: الأحدث أولًا ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 100, "2026-08-01", "p1"),
    recordIncome(salary, wallet, 200, "2026-09-15", "p2"),
    recordIncome(salary, wallet, 300, "2026-08-20", "p1"),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: sarMap });
  assertEqual(report.rows.map((r) => r[1]), ["2026-09-15", "2026-08-20", "2026-08-01"], "7-أ: الترتيب تنازليًا حسب التاريخ (الأحدث أولًا)");
}

console.log("\n=== 8) ظهور operationNumber الصريح ===\n");
{
  const e = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
  e.operationNumber = "0099";
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers([e]), accounts: allAccounts, accountCurrencies: sarMap });
  assertEqual(report.columns[0], "رقم العملية", "8-أ: أول عمود هو 'رقم العملية'");
  assertEqual(report.rows[0][0], "0099", "8-ب: الرقم الصريح المحفوظ يظهر كما هو تمامًا");
}

console.log("\n=== 9) العمليات القديمة بلا operationNumber تعرض رقم العرض الجاهز (بلا أي كتابة جديدة) ===\n");
{
  const legacy: JournalEntry = {
    id: "je_legacy_1",
    entryDate: "2026-07-01",
    transactionType: "income",
    periodId: "p0",
    lines: [
      { accountId: wallet.id, direction: "DEBIT", amount: 500 },
      { accountId: salary.id, direction: "CREDIT", amount: 500 },
    ],
  };
  const entriesWithNumbers = withDisplayNumbers([legacy]);
  assertTrue(legacy.operationNumber === undefined, "9-أ: القيد الأصلي في الذاكرة لم يُكتَب إليه أي رقم (بلا طفرة جانبية)");
  const { document: report } = buildTransactionLogReport({ entries: entriesWithNumbers, accounts: allAccounts, accountCurrencies: sarMap });
  assertEqual(report.rows[0][0], "0001", "9-ب: رقم العرض المحسوب (0001) يظهر في التقرير بدل قيمة فارغة");
}

console.log("\n=== 10) لا جمع بين عملتين مختلفتين في إجمالي واحد ===\n");
{
  const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
  const mixedMap = new Map<string, Currency>(allAccounts.map((a) => [a.id, DEFAULT_CURRENCY]));
  mixedMap.set(wallet2.id, usd);
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 1000, "2026-08-01", "p1"),
    recordExpense(food, wallet2, 300, "2026-08-02", "p1", true, 0),
  ];
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers(entries), accounts: allAccounts, accountCurrencies: mixedMap });
  const totalKeys = Object.keys(report.totals || {}).filter((k) => k.startsWith("إجمالي ("));
  assertEqual(totalKeys.length, 2, "10-أ: مفتاحا إجمالي منفصلان — واحد لكل عملة فعليًا موجودة، لا مفتاح مختلط واحد");
  assertTrue(totalKeys.some((k) => k.includes("ريال سعودي")), "10-ب: أحد المفاتيح خاص بالريال السعودي");
  assertTrue(totalKeys.some((k) => k.includes("دولار أمريكي")), "10-ج: والآخر خاص بالدولار الأمريكي — منفصلان تمامًا");
}

console.log("\n=== 11) عدم تعديل أي بيانات أثناء بناء التقرير (دالة نقية بالكامل) ===\n");
{
  const e = recordDirectEntry(wallet, debt, 250, "2026-08-01", "p1", "تسوية");
  const original = JSON.parse(JSON.stringify(e));
  buildTransactionLogReport({ entries: withDisplayNumbers([e]), accounts: allAccounts, accountCurrencies: sarMap, fromDate: "2026-01-01", transactionType: "direct_entry", accountId: wallet.id, currencyCode: "SAR" });
  assertEqual(e, original, "11-أ: القيد الأصلي لم يتغيّر بايتًا واحدًا بعد بناء التقرير بكل الفلاتر معًا");
  assertEqual(wallet, JSON.parse(JSON.stringify(wallet)), "11-ب: كائن الحساب نفسه لم يتأثر أيضًا");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات سجل العمليات (المرحلة 5، الخطوة 2): ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
