import { Account, JournalEntry } from "../src/types";
import { computeBalance } from "../src/ledger";
import { recordIncome, recordExpense, recordRecurringDebtPayment, recordTransfer } from "../src/transactions";
import { computeVariance } from "../src/variance";
import { determineStage, forcedPaydown, reduceMinThenBalance } from "../src/recurringDebt";
import { runDistribution, DistributionInput, ExpenseInput, GoalInput, RecurringDebtInput } from "../src/distribution";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    passed++;
    console.log(`✅ ${label}`);
  } else {
    failed++;
    console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`);
  }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}

function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

function totalAllocatedToAccount(result: { allocations: { accountId: string; amount: number }[] }, accountId: string): number {
  return round2(result.allocations.filter((a) => a.accountId === accountId).reduce((s, a) => s + a.amount, 0));
}
function round2(n: number): number { return Math.round((n + Number.EPSILON) * 100) / 100; }

// حسابات مشتركة لعدة سيناريوهات
const food = acc("exp_food", "طعام", "expense");
const rent = acc("exp_rent", "إيجار", "expense");
const elec = acc("exp_elec", "كهرباء", "expense");
const water = acc("exp_water", "ماء", "expense");
const goalCar = acc("goal_car", "هدف السيارة", "goal");
const debtA = acc("debt_a", "دين لمرة واحدة A", "one_time_debt");
const debtB = acc("debt_b", "دين لمرة واحدة B", "one_time_debt");
const recDebt = acc("rec_debt", "بطاقة ائتمان مستمرة", "recurring_debt");
const reserve = acc("reserve_1", "الاحتياطي", "reserve");

function baseExpenses(): ExpenseInput[] {
  return [
    { account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high" },
    { account: rent, monthlyMin: 15000, monthlyMax: 15000, priority: "essential_high" },
    { account: elec, monthlyMin: 5000, monthlyMax: 8000, priority: "essential" },
    { account: water, monthlyMin: 3000, monthlyMax: 4000, priority: "essential" },
  ];
}

// نسخة بلا هامش رفع (max=min) — تُستخدَم في سيناريوهات تختبر مراحل لاحقة (5+) بمعزل عن Stage 3
// حتى لا يستهلك "رفع المصروفات نحو الحد الأعلى" الفائضَ المخصَّص أصلًا لاختبار مرحلة أخرى.
function flatExpenses(): ExpenseInput[] {
  return baseExpenses().map((e) => ({ ...e, monthlyMax: e.monthlyMin }));
}

console.log("=== سيناريو أ: دخل يكفي جميع الحدود الدنيا بالضبط ولا يتبقى شيء (33,000) ===\n");
{
  const input: DistributionInput = {
    periodId: "p_a",
    incomeAvailable: 33000,
    expenses: baseExpenses(),
    goals: [],
    oneTimeDebts: [],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  assertEqual(r.insufficientAllocationReport, undefined, "أ: لا يوجد تقرير عجز");
  assertEqual(totalAllocatedToAccount(r, food.id), 10000, "أ: طعام يحصل على حده الأدنى 10,000 بالضبط");
  assertEqual(totalAllocatedToAccount(r, rent.id), 15000, "أ: إيجار يحصل على 15,000 بالضبط");
  assertEqual(totalAllocatedToAccount(r, elec.id), 5000, "أ: كهرباء 5,000");
  assertEqual(totalAllocatedToAccount(r, water.id), 3000, "أ: ماء 3,000");
  assertEqual(r.remainingAfterAllStages, 0, "أ: لا يتبقى شيء بعد كل المراحل");
}

console.log("\n=== سيناريو ب: دخل أقل من مجموع الحدود الدنيا (25,000 مقابل 33,000) ===\n");
{
  const input: DistributionInput = {
    periodId: "p_b",
    incomeAvailable: 25000,
    expenses: baseExpenses(),
    goals: [{ account: goalCar, minAllocation: 5000, maxAllocation: 10000, targetAmount: 100000, achievedAmount: 0, priority: "critical" }],
    oneTimeDebts: [],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  assertTrue(r.insufficientAllocationReport !== undefined, "ب: تقرير عجز موجود");
  assertEqual(r.insufficientAllocationReport?.totalRequired, 33000, "ب: إجمالي الحد الأدنى المطلوب = 33,000");
  assertEqual(r.insufficientAllocationReport?.totalUnfunded, 8000, "ب: مقدار العجز = 8,000");
  assertEqual(totalAllocatedToAccount(r, food.id), 10000, "ب: طعام(essential_high) يُموَّل بالكامل 10,000 (الأولوية الصارمة)");
  assertEqual(totalAllocatedToAccount(r, rent.id), 15000, "ب: إيجار(essential_high) يُموَّل بالكامل 15,000");
  assertEqual(totalAllocatedToAccount(r, elec.id), 0, "ب: كهرباء(essential) لا تحصل على شيء — نفد الدخل");
  assertEqual(totalAllocatedToAccount(r, water.id), 0, "ب: ماء(essential) لا تحصل على شيء");
  assertEqual(totalAllocatedToAccount(r, goalCar.id), 0, "ب: الهدف (Stage 2) لا يُموَّل إطلاقًا لأن الحدود الدنيا لم تُغطَّ بالكامل");
  const shortfalls = r.insufficientAllocationReport?.perAccount.filter((u) => u.remaining > 0).map((u) => u.accountId).sort();
  assertEqual(shortfalls, [elec.id, water.id].sort(), "ب: الحسابات غير الممولة = كهرباء وماء بالضبط");
}

console.log("\n=== سيناريو ج: دخل يكفي الحدود الدنيا ويتبقى فائض بسيط (40,000) ===\n");
{
  const input: DistributionInput = {
    periodId: "p_c",
    incomeAvailable: 40000,
    expenses: baseExpenses(),
    goals: [{ account: goalCar, minAllocation: 5000, maxAllocation: 10000, targetAmount: 100000, achievedAmount: 0, priority: "critical" }],
    oneTimeDebts: [],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  assertEqual(r.insufficientAllocationReport, undefined, "ج: لا يوجد عجز");
  // 33,000 حدود دنيا + 5,000 هدف حرج = 38,000 → يتبقى 2,000 لرفع essential_high (طعام يحتاج +5,000، إيجار +0)
  assertEqual(totalAllocatedToAccount(r, goalCar.id), 5000, "ج: الهدف الحرج يحصل على حده الأدنى 5,000 (Stage 2)");
  assertEqual(totalAllocatedToAccount(r, food.id), 12000, "ج: طعام = 10,000 + رفع 2,000 من الفائض المتبقي (Stage 3، لا منافس آخر باحتياج في essential_high)");
  assertEqual(r.remainingAfterAllStages, 0, "ج: كل الفائض استُهلك في الرفع");
}

console.log("\n=== سيناريو د: دخل كبير يصل للحدود العليا ثم الادخار (200,000) ===\n");
{
  const input: DistributionInput = {
    periodId: "p_d",
    incomeAvailable: 200000,
    expenses: baseExpenses(),
    goals: [{ account: goalCar, minAllocation: 5000, maxAllocation: 20000, targetAmount: 100000, achievedAmount: 0, priority: "critical" }],
    oneTimeDebts: [],
    recurringDebts: [],
    reserve: { account: reserve },
  };
  const r = runDistribution(input);
  assertEqual(totalAllocatedToAccount(r, food.id), 15000, "د: طعام يصل حده الأعلى 15,000");
  assertEqual(totalAllocatedToAccount(r, rent.id), 15000, "د: إيجار عند حده الأعلى=الأدنى 15,000");
  assertEqual(totalAllocatedToAccount(r, elec.id), 8000, "د: كهرباء تصل حدها الأعلى 8,000");
  assertEqual(totalAllocatedToAccount(r, water.id), 4000, "د: ماء يصل حده الأعلى 4,000");
  // تصحيح: المواصفة لا تنص على مرحلة "رفع الهدف نحو الحد الأعلى" — Stage 2/4 يخصصان الحد الأدنى فقط لكل هدف (minAllocation).
  // الهدف هنا أولوية critical واحد فقط، فيحصل على 5,000 في Stage 2 ولا يُموَّل أكثر في أي مرحلة لاحقة صراحةً بالمواصفة.
  assertEqual(totalAllocatedToAccount(r, goalCar.id), 5000, "د: الهدف يحصل على حده الأدنى فقط 5,000 (Stage 2) — لا توجد مرحلة مواصفة تُخصِّص أكثر من الحد الأدنى للأهداف");
  const expectedReserve = round2(200000 - (15000 + 15000 + 8000 + 4000 + 5000));
  assertEqual(totalAllocatedToAccount(r, reserve.id), expectedReserve, `د: الفائض النهائي (${expectedReserve}) يذهب للاحتياطي (Stage 8)`);
  assertEqual(r.remainingAfterAllStages, 0, "د: لا يتبقى شيء غير موزَّع");
}

console.log("\n=== سيناريو هـ: وجود عجز مرحّل من الشهر السابق (Stage 0) ===\n");
{
  const input: DistributionInput = {
    periodId: "p_e",
    incomeAvailable: 40000,
    expenses: baseExpenses(),
    goals: [{ account: goalCar, minAllocation: 5000, maxAllocation: 10000, targetAmount: 100000, achievedAmount: 0, priority: "critical", carriedDeficit: 4000 }],
    oneTimeDebts: [],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  const stage0Alloc = r.allocations.find((a) => a.accountId === goalCar.id && a.stage === 0);
  assertTrue(stage0Alloc !== undefined && stage0Alloc.amount === 4000, "هـ: العجز المرحّل (4,000) للهدف يُموَّل في Stage 0 قبل أي شيء آخر");
  // بعد ذلك: 40,000-4,000=36,000 متاح لـ Stage1(33,000 حدود دنيا) → يتبقى 3,000 لـ Stage2(هدف min=5,000، يُموَّل جزئيًا أو حسب المتاح)
  assertEqual(totalAllocatedToAccount(r, food.id), 10000, "هـ: طعام يُموَّل بالكامل رغم خصم العجز المرحّل أولًا");
  const stage2Alloc = r.allocations.find((a) => a.accountId === goalCar.id && a.stage === 2);
  assertEqual(stage2Alloc?.amount, 3000, "هـ: بعد Stage0 وStage1 يتبقى 3,000 فقط لتمويل جزء من حد الهدف الأدنى في Stage2");
}

console.log("\n=== سيناريو و: وجود فائض مرحّل حر من الشهر السابق ===\n");
{
  const input: DistributionInput = {
    periodId: "p_f",
    incomeAvailable: 33000, // يغطي الحدود الدنيا بالضبط فقط
    freeCarriedSurplus: 6000, // فائض حر إضافي من إغلاق الشهر السابق
    expenses: baseExpenses(),
    goals: [],
    oneTimeDebts: [],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  assertEqual(r.totalIncomeAvailable, 39000, "و: إجمالي المتاح = الدخل + الفائض المرحّل الحر = 39,000");
  assertEqual(totalAllocatedToAccount(r, food.id), 15000, "و: الفائض المرحّل يرفع طعام لحده الأعلى 15,000 (Stage3، أولوية essential_high تُشبَع أولًا بالكامل قبل essential)");
  // بعد إشباع essential_high (استهلك 5,000 من الفائض)، يتبقى 1,000 يُوزَّع تناسبيًا على essential (كهرباء تحتاج 3,000، ماء يحتاج 1,000)
  assertEqual(totalAllocatedToAccount(r, elec.id), 5750, "و: كهرباء = 5,000 (Stage1) + 750 تناسبيًا من الـ1,000 المتبقية (Stage3) = 5,750");
  assertEqual(totalAllocatedToAccount(r, water.id), 3250, "و: ماء = 3,000 (Stage1) + 250 تناسبيًا من الـ1,000 المتبقية (Stage3) = 3,250");
  assertEqual(r.remainingAfterAllStages, 0, "و: كل الفائض المرحّل استُهلك بالكامل بين طعام وكهرباء وماء تناسبيًا — لا شيء يتبقى");
}

console.log("\n=== سيناريو ز: دين مستمر يبدأ تحت الحد الأدنى ثم يرتفع حتى الحد الأعلى ===\n");
{
  const min = 10000, max = 50000;
  let balance = 2000; // تحت الحد الأدنى
  assertEqual(determineStage({ accountId: "d", balance, minLimit: min, maxLimit: max }), "min_reduction_ready", "ز: عند 2,000 (تحت الأدنى) → الحالة min_reduction_ready");
  balance = 25000; // بين الحدين
  assertEqual(determineStage({ accountId: "d", balance, minLimit: min, maxLimit: max }), "rising", "ز: عند 25,000 (بين الحدين) → الحالة rising");
  balance = 50000; // بلغ الحد الأعلى بالضبط
  assertEqual(determineStage({ accountId: "d", balance, minLimit: min, maxLimit: max }), "forced_paydown", "ز: عند 50,000 (=الحد الأعلى) → forced_paydown");
  balance = 61000; // تجاوز الحد الأعلى
  assertEqual(determineStage({ accountId: "d", balance, minLimit: min, maxLimit: max }), "forced_paydown", "ز: عند 61,000 (تجاوز الحد الأعلى) → forced_paydown");
}

console.log("\n=== سيناريو ح: دين مستمر يبلغ الحد الأعلى ثم يبدأ السداد حتى الحد الأدنى ===\n");
{
  const state = { accountId: "rec_debt", balance: 53000, minLimit: 10000, maxLimit: 50000 };
  const result = forcedPaydown(state, 15000); // متاح 15,000، الاحتياج للوصول للأدنى = 43,000
  assertEqual(result.amountAllocated, 15000, "ح: يُخصَّص كل المتاح (15,000) لأن الاحتياج (43,000) أكبر منه");
  assertEqual(result.newBalanceProjected, 38000, "ح: الرصيد الجديد = 53,000-15,000 = 38,000");
  assertEqual(result.stageAfter, "rising", "ح: الحالة بعد السداد الجزئي = rising (لا يزال فوق الحد الأدنى)");

  const state2 = { accountId: "rec_debt", balance: 53000, minLimit: 10000, maxLimit: 50000 };
  const result2 = forcedPaydown(state2, 100000); // متاح كبير — يجب أن يتوقف عند الحد الأدنى بالضبط وليس صفرًا
  assertEqual(result2.amountAllocated, 43000, "ح: عند توفر فائض كبير، السداد الإجباري يتوقف عند الوصول للحد الأدنى بالضبط (43,000) وليس أكثر");
  assertEqual(result2.newBalanceProjected, 10000, "ح: الرصيد الجديد = الحد الأدنى (10,000)");
  assertEqual(result2.stageAfter, "min_reduction_ready", "ح: الحالة بعد الوصول للحد الأدنى = min_reduction_ready");
}

console.log("\n=== سيناريو ط: دين مستمر يُخفَّض حده الأدنى تدريجيًا حتى الصفر ثم يُغلَق (وفق القاعدة الحاسمة: الفائض نفسه يقرر، لا معامل خارجي) ===\n");
{
  let state = { accountId: "rec_debt", balance: 10000, minLimit: 10000, maxLimit: 50000 };
  // دورة 1: فائض 3,000 متاح — أقل من الحد الأدنى بالكامل، فيُستهلَك كله في تخفيض الحد الأدنى فقط
  let r1 = reduceMinThenBalance(state, 3000);
  assertEqual(r1.reducedMinLimitBy, 3000, "ط-1: الفائض (3,000) بالكامل يخفّض الحد الأدنى المقترح (10,000→7,000)");
  assertEqual(r1.reducedBalanceBy, 0, "ط-1: لا شيء يخفّض الرصيد بعد — الحد الأدنى لم يصل صفرًا");
  assertEqual(r1.newMinLimitProposed, 7000, "ط-1: الحد الأدنى المقترح الجديد = 7,000");
  assertEqual(r1.newBalanceProjected, 10000, "ط-1: الرصيد المُسقَط دون تغيير (10,000) — لم يُسدَّد فعليًا بعد");
  // المستخدم يعتمد المقترح (ApprovedParameterChange) ثم يسدد فعليًا 3,000 عبر transactions.ts بشكل منفصل تمامًا
  state = { accountId: "rec_debt", balance: 7000, minLimit: 7000, maxLimit: 50000 };
  let r2 = reduceMinThenBalance(state, 4000);
  assertEqual(r2.stageBefore, "min_reduction_ready", "ط-2: الحالة قبل التخفيض = min_reduction_ready (عند الحد الأدنى بالضبط)");
  assertEqual(r2.reducedMinLimitBy, 4000, "ط-2: تخفيض إضافي من 7,000 إلى 3,000");
  assertEqual(r2.newMinLimitProposed, 3000, "ط-2: الحد الأدنى المقترح = 3,000");
  assertEqual(r2.reducedBalanceBy, 0, "ط-2: الرصيد لا يزال دون تغيير");
  // اعتماد + سداد فعلي منفصل حتى الحد الأدنى الجديد
  state = { accountId: "rec_debt", balance: 3000, minLimit: 3000, maxLimit: 50000 };
  let r3 = reduceMinThenBalance(state, 3000);
  assertEqual(r3.reducedMinLimitBy, 3000, "ط-3: الحد الأدنى يصل صفرًا (3,000→0)");
  assertEqual(r3.reducedBalanceBy, 0, "ط-3: لا يزال الرصيد بلا تغيير — الفائض استُهلك بالكامل في الحد الأدنى فقط");
  assertEqual(r3.newMinLimitProposed, 0, "ط-3: الحد الأدنى = صفر الآن");
  assertEqual(r3.stageAfter, "final_payoff", "ط-3: الحالة التالية = final_payoff (الحد الأدنى صفر، الرصيد لا يزال 3,000)");
  // الآن الحد الأدنى=صفر فعليًا (بعد اعتماد سابق) — أي فائض جديد يخفّض الرصيد مباشرة حتى الإغلاق
  state = { accountId: "rec_debt", balance: 3000, minLimit: 0, maxLimit: 50000 };
  let r4 = reduceMinThenBalance(state, 3000);
  assertEqual(r4.stageBefore, "final_payoff", "ط-4: الحد الأدنى=صفر → الحالة final_payoff");
  assertEqual(r4.reducedMinLimitBy, 0, "ط-4: لا يوجد حد أدنى ليُخفَّض");
  assertEqual(r4.reducedBalanceBy, 3000, "ط-4: الفائض بالكامل يخفّض الرصيد مباشرة (3,000→0)");
  assertEqual(r4.newBalanceProjected, 0, "ط-4: الرصيد المُسقَط = صفر");
  assertEqual(r4.stageAfter, "closed", "ط-4: الحالة بعد السداد الكامل = closed");
  // أي محاولة تقدّم لاحقة على حساب مغلق فعليًا (رصيد حقيقي = صفر من الدفتر)
  let r5 = reduceMinThenBalance({ accountId: "rec_debt", balance: 0, minLimit: 0, maxLimit: 50000 }, 5000);
  assertEqual(r5.reducedBalanceBy, 0, "ط-5: حساب مغلق فعليًا (رصيد=0) لا يستقبل أي تخصيص إضافي");
  assertEqual(r5.leftoverUnused, 5000, "ط-5: كل الفائض يتدفق كـ leftoverUnused للعنصر التالي في الطابور");
}

console.log("\n=== سيناريو ي: إغلاق دين لمرة واحدة وإعادة توجيه المبلغ المخصص تلقائيًا ===\n");
{
  const input: DistributionInput = {
    periodId: "p_i",
    incomeAvailable: 33000 + 10000, // حدود دنيا + 10,000 لتوزيعها على الديون لمرة واحدة
    expenses: flatExpenses(), // max=min عمدًا: بلا هامش رفع، لعزل الاختبار عن Stage 3 (الذي يسبق Stage 5 في الترتيب)
    goals: [],
    oneTimeDebts: [
      { account: debtA, remainingBalance: 0, priority: "urgent_high" }, // مغلق بالفعل
      { account: debtB, remainingBalance: 6000, priority: "urgent" },
    ],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  assertEqual(totalAllocatedToAccount(r, debtA.id), 0, "ي: دين A مغلق (رصيد=0) لا يحصل على أي تخصيص");
  assertEqual(totalAllocatedToAccount(r, debtB.id), 6000, "ي: كامل مبلغ B (6,000) يُموَّل — أموال A لم تُهدَر، تدفقت تلقائيًا للأولوية التالية");
  assertEqual(r.remainingAfterAllStages, 4000, "ي: الباقي (10,000-6,000=4,000) يستمر متاحًا للمراحل التالية دون فقدان (لا احتياطي مُعرَّف هنا)");
}

console.log("\n=== سيناريو ك: دخل جديد منتصف الشهر وإعادة حساب التوزيع دون إفساد العمليات السابقة ===\n");
{
  const wallet = acc("wallet_k", "المحفظة", "pot");
  const salary = acc("salary_k", "راتب", "income_source");
  const entries: JournalEntry[] = [];
  entries.push(recordIncome(salary, wallet, 50000, "2026-08-01", "p_k"));
  entries.push(recordExpense(food, wallet, 8000, "2026-08-05", "p_k", false, computeBalance(wallet, entries)));
  const balanceBeforeSecondIncome = computeBalance(wallet, entries);

  const firstRun = runDistribution({ periodId: "p_k", incomeAvailable: 50000, expenses: flatExpenses(), goals: [], oneTimeDebts: [], recurringDebts: [] });

  // دخل إضافي يدخل منتصف الشهر
  entries.push(recordIncome(salary, wallet, 20000, "2026-08-15", "p_k"));
  const secondRun = runDistribution({ periodId: "p_k", incomeAvailable: 70000, expenses: flatExpenses(), goals: [], oneTimeDebts: [], recurringDebts: [] });

  assertEqual(computeBalance(wallet, entries), balanceBeforeSecondIncome + 20000, "ك: القيود التاريخية (الفعلي) لم تتأثر إطلاقًا بإعادة حساب التوزيع");
  assertTrue(secondRun.incomeAvailable > firstRun.incomeAvailable, "ك: إعادة الحساب تعكس الدخل الجديد بالكامل (70,000 > 50,000)");
  assertEqual(secondRun.remainingAfterAllStages, round2(70000 - 33000), "ك: التوزيع الجديد مستقل تمامًا (دالة نقية) ويحسب من الصفر بالمدخلات الجديدة فقط (لا هامش رفع هنا، فيبقى الفائض غير مخصَّص لعدم وجود احتياطي مُعرَّف)");
}

console.log("\n=== سيناريو ل: تسجيل مصروف فعلي يتجاوز المخصص ===\n");
{
  const v = computeVariance(food, 10000, 13500, false);
  assertEqual({ type: v.varianceType, amount: v.variance }, { type: "deficit", amount: 3500 }, "ل: فعلي 13,500 مقابل معتمد 10,000 → تجاوز/عجز 3,500 (وليس فائضًا بأي حال)");
}

console.log("\n=== سيناريو م: تسجيل مصروف فعلي أقل من المخصص ===\n");
{
  const v = computeVariance(food, 10000, 6200, false);
  assertEqual({ type: v.varianceType, amount: v.variance, pending: v.pendingPeriodClose }, { type: "surplus", amount: 3800, pending: true }, "م: فعلي 6,200 مقابل معتمد 10,000 → فائض 3,800 (معلَّق حتى إغلاق الدورة)");
}

console.log("\n=== سيناريو ن: أكثر من وعاء مالي والتحقق من مصدر السداد الصحيح ===\n");
{
  const potCash = acc("pot_cash", "نقد", "pot");
  const potBank = acc("pot_bank", "بنك", "pot");
  const salary2 = acc("salary_n", "راتب", "income_source");
  const entries: JournalEntry[] = [];
  entries.push(recordIncome(salary2, potBank, 40000, "2026-08-01", "p_n"));
  entries.push(recordTransfer(potBank, potCash, 5000, "2026-08-02", "p_n"));
  entries.push(recordExpense(food, potCash, 2000, "2026-08-03", "p_n", false, computeBalance(potCash, entries)));

  assertEqual(computeBalance(potBank, entries), 35000, "ن: رصيد البنك = 40,000-5,000(تحويل) = 35,000 (لم يتأثر بمصروف النقد)");
  assertEqual(computeBalance(potCash, entries), 3000, "ن: رصيد النقد = 5,000-2,000(مصروف) = 3,000 (لم يتأثر بأي عملية بنكية)");
  assertEqual(computeBalance(food, entries), 2000, "ن: حساب المصروف مرتبط فقط بوعاء النقد الصحيح كطرف دائن، بمبلغ 2,000");
}

console.log("\n=== سيناريو س: القيد المزدوج — كل عملية تؤثر على الحسابات المقابلة بصورة صحيحة (فحص شامل) ===\n");
{
  const wallet = acc("wallet_s", "محفظة", "pot");
  const salary3 = acc("salary_s", "راتب", "income_source");
  const debtS = acc("debt_s", "دين مستمر", "recurring_debt");
  const entries: JournalEntry[] = [];
  entries.push(recordIncome(salary3, wallet, 30000, "2026-08-01", "p_s"));
  entries.push(recordExpense(food, wallet, 4000, "2026-08-02", "p_s", false, computeBalance(wallet, entries)));
  entries.push(recordRecurringDebtPayment(debtS, wallet, 2000, "2026-08-03", "p_s"));

  // فحص هوية محاسبية أساسية: إجمالي كل المدين عبر كل القيود = إجمالي كل الدائن عبر كل القيود (ميزان المراجعة)
  let totalDebit = 0, totalCredit = 0;
  for (const e of entries) for (const l of e.lines) { if (l.direction === "DEBIT") totalDebit += l.amount; else totalCredit += l.amount; }
  assertEqual(round2(totalDebit), round2(totalCredit), "س: ميزان المراجعة الكلي متوازن (إجمالي كل المدين = إجمالي كل الدائن عبر كل العمليات)");

  assertEqual(computeBalance(wallet, entries), 30000 - 4000 - 2000, "س: رصيد الوعاء = دخل - مصروف - سداد = 24,000");
  assertEqual(computeBalance(salary3, entries), 30000, "س: حساب الدخل (دائن) = 30,000");
  assertEqual(computeBalance(food, entries), 4000, "س: حساب المصروف (مدين) = 4,000");
  assertEqual(computeBalance(debtS, entries), -2000, "س: حساب الدين المستمر (دائن الطبيعة) بعد سداد فقط دون إنشاء التزام سابق = -2,000 (يعكس أن السداد سابق لأي التزام مُسجَّل، وهو سيناريو غير واقعي عمليًا لكنه يثبت صحة اتجاه القيد رياضيًا)");
}

console.log(`\n\n=== النتيجة الإجمالية: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
