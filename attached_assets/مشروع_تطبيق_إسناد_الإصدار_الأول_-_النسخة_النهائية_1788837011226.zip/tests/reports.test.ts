import { Account, JournalEntry } from "../src/types";
import { computeBalance } from "../src/ledger";
import { recordIncome, recordExpense } from "../src/transactions";
import { buildAccountLedgerReport, renderReportToHtml } from "../src/reports";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
function acc(id: string, name: string, category: Account["category"], opening = 0): Account {
  return { id, name, category, openingBalance: opening, status: "active" };
}

const wallet = acc("acc_wallet", "المحفظة", "pot");
const salary = acc("acc_salary", "الراتب", "income_source");
const food = acc("acc_food", "طعام", "expense");
const allAccounts = [wallet, salary, food];

console.log("=== 1) الرصيد المتحرك في التقرير يطابق computeBalance الحقيقية بالضبط ===\n");
{
  const entries: JournalEntry[] = [];
  entries.push(recordIncome(salary, wallet, 50000, "2026-08-01", "p1"));
  entries.push(recordExpense(food, wallet, 12000, "2026-08-05", "p1", false, 50000));
  entries.push(recordIncome(salary, wallet, 10000, "2026-08-10", "p1"));

  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries });
  const lastRowBalance = Number(report.rows[report.rows.length - 1][5].replace(/,/g, ""));
  const realBalance = computeBalance(wallet, entries);
  assertEqual(lastRowBalance, realBalance, "1-أ: آخر صف في التقرير (48,000) يطابق computeBalance الحقيقية تمامًا");
  assertEqual(realBalance, 48000, "1-ب: الرصيد الفعلي = 50,000-12,000+10,000 = 48,000");
  assertEqual(report.rows.length, 3, "1-ج: ثلاثة أسطر (لا رصيد افتتاحي لأنه صفر)");
}

console.log("\n=== 2) اسم الحساب المقابل مطويّ داخل عمود 'البيان' لكل سطر (الملاحظة 3 — لا عمود مستقل) ===\n");
{
  const entries: JournalEntry[] = [recordIncome(salary, wallet, 50000, "2026-08-01", "p1")];
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries });
  assertTrue(report.rows[0][2].includes("الراتب"), "2-أ: بيان عملية الدخل من منظور المحفظة يتضمَّن اسم الحساب المقابل (الراتب)");
  const reportFromSalary = buildAccountLedgerReport({ account: salary, allAccounts, entries });
  assertTrue(reportFromSalary.rows[0][2].includes("المحفظة"), "2-ب: من منظور الراتب، البيان يتضمَّن اسم الحساب المقابل (المحفظة)");
}

console.log("\n=== 3) فلترة الفترة (fromDate/toDate) ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 50000, "2026-08-01", "p1"),
    recordIncome(salary, wallet, 10000, "2026-09-01", "p2"),
  ];
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries, fromDate: "2026-09-01" });
  assertEqual(report.rows.length, 1, "3-أ: فلترة fromDate تستبعد عملية أغسطس وتُبقي سبتمبر فقط");
  assertEqual(report.rows[0][0], "2026-09-01", "3-ب: التاريخ الباقي صحيح");
}

console.log("\n=== 4) رصيد افتتاحي غير صفري يظهر كسطر أول ===\n");
{
  const walletWithOpening = acc("acc_wallet2", "محفظة بافتتاحي", "pot", 5000);
  const entries: JournalEntry[] = [recordIncome(salary, walletWithOpening, 1000, "2026-08-01", "p1")];
  const report = buildAccountLedgerReport({ account: walletWithOpening, allAccounts: [...allAccounts, walletWithOpening], entries });
  assertEqual(report.rows[0][2], "رصيد افتتاحي", "4-أ: أول سطر يوضّح الرصيد الافتتاحي (5,000)");
  const lastBalance = Number(report.rows[report.rows.length - 1][5].replace(/,/g, ""));
  assertEqual(lastBalance, 6000, "4-ب: الرصيد النهائي = 5,000+1,000 = 6,000 (يطابق computeBalance)");
  assertEqual(lastBalance, computeBalance(walletWithOpening, entries), "4-ج: مطابق تمامًا لـcomputeBalance الحقيقية");
}

console.log("\n=== 5) إجماليات مدين/دائن صحيحة ===\n");
{
  const entries: JournalEntry[] = [
    recordIncome(salary, wallet, 50000, "2026-08-01", "p1"),
    recordExpense(food, wallet, 12000, "2026-08-05", "p1", false, 50000),
  ];
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries });
  assertEqual(report.totals?.["إجمالي مدين"], (50000).toLocaleString("en-US"), "5-أ: إجمالي مدين المحفظة = 50,000 (الدخل)");
  assertEqual(report.totals?.["إجمالي دائن"], (12000).toLocaleString("en-US"), "5-ب: إجمالي دائن المحفظة = 12,000 (المصروف)");
}

console.log("\n=== 6) التحويل إلى HTML قابل للطباعة يتضمن كل العناصر الأساسية ===\n");
{
  const entries: JournalEntry[] = [recordIncome(salary, wallet, 50000, "2026-08-01", "p1")];
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries });
  const html = renderReportToHtml(report);
  assertTrue(html.includes("تقرير حساب: المحفظة"), "6-أ: العنوان موجود في HTML");
  assertTrue(html.includes("<table"), "6-ب: جدول العمليات موجود");
  assertTrue(html.includes("الرصيد النهائي"), "6-ج: الإجماليات موجودة");
}

console.log("\n=== 7) حساب بلا عمليات إطلاقًا ينتج تقريرًا فارغًا صحيحًا (لا خطأ) ===\n");
{
  const emptyAccount = acc("acc_empty", "حساب فارغ", "expense");
  const report = buildAccountLedgerReport({ account: emptyAccount, allAccounts, entries: [] });
  assertEqual(report.rows.length, 0, "7-أ: لا أسطر");
  const html = renderReportToHtml(report);
  assertTrue(html.includes("لا عمليات"), "7-ب: رسالة واضحة بدل جدول فارغ مربك");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات طبقة التقارير: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
