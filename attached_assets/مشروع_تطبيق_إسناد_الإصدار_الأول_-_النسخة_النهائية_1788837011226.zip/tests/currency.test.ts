// ============================================================
// اختبارات نظام العملات المتعددة (Multi-Currency) — المرحلة الأولى من استعادة المشروع.
// تغطي: Currency CRUD، AccountCurrencyLink، ensureDefaultCurrency، وسلامة الترقية
// من ملف دَمب قديم (بلا حقلي currencies/accountCurrencyLinks إطلاقًا — يمثّل حالة
// DB_VERSION=2 السابقة لهذه المرحلة) دون فقدان أي بيانات قديمة.
// ============================================================
import { Account } from "../src/types";
import { recordIncome } from "../src/transactions";
import { FileStorageAdapter } from "../src/storage";
import { Repository } from "../src/repository";
import { Currency, DEFAULT_CURRENCY } from "../src/currency";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;
const DB_FILE = "/tmp/isnad_test_currency_db.json";

async function main() {
  const fs = require("fs");
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);

  console.log("=== 1) Currency CRUD أساسي عبر Repository/FileStorageAdapter ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    assertEqual(await repo.getAllCurrencies(), [], "1-أ: لا عملات في قاعدة بيانات جديدة تمامًا");

    const sar: Currency = { code: "SAR", name: "ريال سعودي", symbol: "ر.س" };
    const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
    await repo.saveCurrency(sar);
    await repo.saveCurrency(usd);

    const all = await repo.getAllCurrencies();
    assertEqual(all.length, 2, "1-ب: عملتان محفوظتان");
    assertEqual(await repo.getCurrency("USD"), usd, "1-ج: استرجاع عملة بمعرّفها (code) يعيد نفس البيانات تمامًا");
    assertEqual(await repo.getCurrency("EUR"), null, "1-د: عملة غير موجودة تعيد null دون استثناء");
  }

  console.log("\n=== 2) ensureDefaultCurrency: توفير عملة افتراضية دون بيانات مالية، وآمن للتكرار ===\n");
  {
    const fs2 = require("fs");
    if (fs2.existsSync(DB_FILE)) fs2.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    await repo.ensureDefaultCurrency();
    const afterFirst = await repo.getAllCurrencies();
    assertEqual(afterFirst.length, 1, "2-أ: بعد أول استدعاء — عملة افتراضية واحدة فقط");
    assertEqual(afterFirst[0], DEFAULT_CURRENCY, "2-ب: العملة المُضافة تطابق DEFAULT_CURRENCY المُصدَّرة");
    assertEqual(await repo.getAllAccounts(), [], "2-ج: لم يُنشأ أي حساب تلقائيًا");
    assertEqual(await repo.getAllJournalEntries(), [], "2-د: لم يُنشأ أي قيد/عملية مالية تلقائيًا");

    // استدعاء ثانٍ لا يكرر الإدراج ولا يكتب فوق عملة أضافها المستخدم بنفس القائمة
    await repo.saveCurrency({ code: "USD", name: "دولار أمريكي", symbol: "$" });
    await repo.ensureDefaultCurrency();
    const afterSecond = await repo.getAllCurrencies();
    assertEqual(afterSecond.length, 2, "2-هـ: استدعاء ensureDefaultCurrency مع وجود عملات بالفعل لا يضيف عملة افتراضية أخرى (لا تكرار)");
  }

  console.log("\n=== 3) AccountCurrencyLink: ربط حساب بعملة، والعملة الفعلية عبر getAccountCurrency ===\n");
  {
    const fs3 = require("fs");
    if (fs3.existsSync(DB_FILE)) fs3.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const wallet = acc("acc_wallet", "المحفظة", "pot");
    await repo.saveAccount(wallet);

    // بلا رابط عملة صريح → العملة الافتراضية (للعرض فقط، ليست بيانات مخزَّنة كرابط)
    const beforeLink = await repo.getAccountCurrency(wallet.id);
    assertEqual(beforeLink, DEFAULT_CURRENCY, "3-أ: حساب بلا رابط عملة صريح → العملة الافتراضية");
    assertEqual(await repo.getAccountCurrencyLink(wallet.id), null, "3-ب: لا يوجد رابط محفوظ فعليًا قبل الربط الصريح");

    const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
    await repo.saveCurrency(usd);
    await repo.saveAccountCurrencyLink({ accountId: wallet.id, currencyCode: "USD" });

    const afterLink = await repo.getAccountCurrency(wallet.id);
    assertEqual(afterLink, usd, "3-ج: بعد الربط الصريح → العملة الفعلية تطابق العملة المرتبطة");

    const links = await repo.getAllAccountCurrencyLinks();
    assertEqual(links.length, 1, "3-د: رابط واحد محفوظ فعليًا في التخزين");

    // ربط بعملة غير موجودة في جدول العملات (حالة حافة) → يرجع للعملة الافتراضية بدل استثناء
    await repo.saveAccountCurrencyLink({ accountId: wallet.id, currencyCode: "XYZ" });
    const brokenLink = await repo.getAccountCurrency(wallet.id);
    assertEqual(brokenLink, DEFAULT_CURRENCY, "3-هـ: رابط بعملة غير محفوظة فعليًا → عملة افتراضية للعرض دون استثناء");
  }

  console.log("\n=== 4) سلامة الترقية: بيانات DB_VERSION=2 القديمة تبقى محفوظة كاملة بعد إضافة العملات ===\n");
  {
    const fs4 = require("fs");
    // نكتب دَمبًا يدويًا يطابق شكل الملف *قبل* هذه المرحلة تمامًا — بلا حقلي
    // currencies/accountCurrencyLinks إطلاقًا (تمامًا كملفات المستخدمين الحاليين).
    const legacyDump = {
      accounts: {
        acc_wallet: { id: "acc_wallet", name: "المحفظة", category: "pot", openingBalance: 100000, status: "active" },
      },
      journalEntries: [],
      periods: {},
      periodCloseResults: {},
      planningSettings: {},
      // ملاحظة: عمدًا بلا currencies و accountCurrencyLinks — هذا هو الاختبار.
    };
    fs4.writeFileSync(DB_FILE, JSON.stringify(legacyDump, null, 2), "utf-8");

    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    // القراءة يجب ألا تنهار، والحساب القديم يجب أن يعود كاملًا كما هو
    const accountsAfterUpgrade = await repo.getAllAccounts();
    assertEqual(accountsAfterUpgrade.length, 1, "4-أ: الحساب القديم (من قبل هذه المرحلة) ما زال موجودًا بعد قراءة الدَمب القديم");
    assertEqual(accountsAfterUpgrade[0].openingBalance, 100000, "4-ب: الرصيد الافتتاحي القديم (100,000) لم يتأثر إطلاقًا");

    // حقول العملات الجديدة تُقرأ فارغة بأمان، لا استثناء ولا قيمة وهمية
    assertEqual(await repo.getAllCurrencies(), [], "4-ج: لا عملات بعد — القراءة من دمب قديم بلا هذا الحقل لا تنهار");
    assertEqual(await repo.getAllAccountCurrencyLinks(), [], "4-د: لا روابط عملة بعد — نفس الأمان");

    // الآن نضيف عملة على هذا الدمب "المُرقَّى" ونتأكد أن الحساب القديم ما زال سليمًا
    await repo.ensureDefaultCurrency();
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    await repo.saveAccountCurrencyLink({ accountId: wallet.id, currencyCode: DEFAULT_CURRENCY.code });

    const accountsAfterWrite = await repo.getAllAccounts();
    assertEqual(accountsAfterWrite.length, 1, "4-هـ: الكتابة للعملات لأول مرة لا تحذف أو تكرر الحساب القديم");
    assertEqual(accountsAfterWrite[0].openingBalance, 100000, "4-و: الرصيد الافتتاحي القديم ما زال 100,000 بعد أول كتابة تتضمن حقول العملات الجديدة");

    // وأن الحساب المحاسبي (ledger) لهذا الحساب القديم ما زال يعمل بلا أي تغيير في السلوك
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(salary);
    const entry = recordIncome(salary, wallet, 5000, "2026-08-01", "p1");
    await repo.persistJournalEntry(entry);
    assertEqual(await repo.getAccountBalance(wallet.id), 105000, "4-ز: منطق القيد المزدوج للحساب القديم يعمل تمامًا كما قبل إضافة العملات (100,000+5,000=105,000)");
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات العملات: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  const fsFinal = require("fs");
  if (fsFinal.existsSync(DB_FILE)) fsFinal.unlinkSync(DB_FILE);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات العملات:", e);
  process.exit(1);
});
