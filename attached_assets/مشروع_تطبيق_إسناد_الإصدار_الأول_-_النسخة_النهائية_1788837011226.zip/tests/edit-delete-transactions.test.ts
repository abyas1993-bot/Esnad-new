// ============================================================
// اختبارات الملاحظة 4: تعديل وحذف العمليات.
// تغطي: التخزين (updateJournalEntry/deleteJournalEntry — الرفض عند عدم الوجود، وبقاء
// appendJournalEntry ترفض overwrite كما كانت)، طبقة Repository (تعديل يحافظ على رقم
// العملية، منع التعديل/الحذف في فترة مغلقة، إعادة حساب الأرصدة والتقارير حيًا بعد
// التعديل/الحذف)، وrecordDirectEntry/updateDirectEntryAndPersist (تحقق العملة).
// لا شيء هنا يمسّ ledger.ts أو transactions.ts أو DB_VERSION أو تصميم التقارير.
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { computeBalance } from "../src/ledger";
import { recordIncome, recordExpense, recordTransfer, recordRecurringDebtPayment, recordOneTimeDebtPayment, recordDirectEntry } from "../src/transactions";
import { FileStorageAdapter } from "../src/storage";
import { Repository, ClosedPeriodEditError, JournalEntryNotFoundError } from "../src/repository";
import { buildAccountLedgerReport } from "../src/reports";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
async function assertRejects(fn: () => Promise<unknown>, errType: Function, label: string) {
  try {
    await fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يُرفَض ولم يُرفَض`);
  } catch (e) {
    if (e instanceof errType) { passed++; console.log(`✅ ${label}`); }
    else { failed++; console.log(`❌ ${label} — رُفض بخطأ من نوع خاطئ: ${(e as Error).message}: ${(e as Error).constructor.name}`); }
  }
}
function acc(id: string, name: string, category: Account["category"], opening = 0): Account {
  return { id, name, category, openingBalance: opening, status: "active" };
}

declare const require: (id: string) => any;
const DB_FILE = "/tmp/isnad_test_edit_delete_db.json";

async function main() {
  const fs = require("fs");
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);

  const wallet = acc("acc_wallet", "المحفظة", "pot");
  const salary = acc("acc_salary", "الراتب", "income_source");
  const salary2 = acc("acc_salary2", "دخل إضافي", "income_source");
  const food = acc("acc_food", "طعام", "expense");

  console.log("=== 1) طبقة التخزين: updateJournalEntry/deleteJournalEntry ترفضان قيدًا غير موجود ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const fake: JournalEntry = { id: "je_ghost", entryDate: "2026-09-01", transactionType: "income", periodId: "p1", lines: [{ accountId: "a", direction: "DEBIT", amount: 10 }, { accountId: "b", direction: "CREDIT", amount: 10 }] };
    await assertRejects(() => storage.updateJournalEntry(fake), Error, "1-أ: updateJournalEntry ترفض قيدًا غير موجود أصلًا");
    await assertRejects(() => storage.deleteJournalEntry("je_ghost"), Error, "1-ب: deleteJournalEntry ترفض قيدًا غير موجود أصلًا");
  }

  console.log("\n=== 2) appendJournalEntry تبقى كما هي تمامًا — لا تزال ترفض الكتابة فوق id موجود ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    const entry = recordIncome(salary, wallet, 1000, "2026-09-01", "p1");
    await repo.persistJournalEntry(entry);
    await assertRejects(() => storage.appendJournalEntry(entry), Error, "2-أ: appendJournalEntry لا تزال ترفض overwrite (لم يتغيّر سلوكها إطلاقًا)");
  }

  console.log("\n=== 3) تعديل عملية يحافظ على رقم العملية (صريح ثم غير صريح) ===\n");
  {
    const fs3 = require("fs"); if (fs3.existsSync(DB_FILE)) fs3.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.saveAccount(salary2);
    await repo.openPeriod({ id: "p1", startDate: "2026-09-01", endDate: "2026-09-30", status: "open" });

    // 3-أ) رقم صريح — يجب أن يبقى كما هو حرفيًا حتى لو تغيّر كل شيء آخر
    const entry = recordIncome(salary, wallet, 1000, "2026-09-01", "p1");
    entry.operationNumber = "0042";
    await repo.persistJournalEntry(entry);

    const corrected = recordIncome(salary2, wallet, 1500, "2026-09-05", "p1"); // مصدر دخل مختلف، مبلغ مختلف، تاريخ مختلف
    const updated = await repo.updateJournalEntryAndPersist(entry.id, corrected);
    assertEqual(updated.operationNumber, "0042", "3-أ: رقم العملية الصريح (0042) بقي كما هو تمامًا بعد التعديل");
    assertEqual(updated.id, entry.id, "3-ب: id الداخلي لم يتغيّر");
    assertEqual(updated.lines.find((l) => l.direction === "CREDIT")?.accountId, salary2.id, "3-ج: البيانات الجديدة (مصدر الدخل المختلف) طُبِّقت فعليًا");

    // 3-د) رقم غير صريح (قيد قديم بلا operationNumber) — يُجمَّد عند أول تعديل بدل أن يبقى عرضيًا متحركًا
    const legacyEntry = recordExpense(food, wallet, 200, "2026-09-10", "p1", true);
    await repo.saveAccount(food);
    await repo.persistJournalEntry(legacyEntry); // بلا operationNumber صريح — سيُمنح رقم عرض (0043 على الأرجح، بعد 0042)
    const beforeEditAll = await repo.getAllJournalEntries();
    const displayBefore = (await repo.getAllJournalEntriesWithDisplayNumbers()).find((e) => e.id === legacyEntry.id)!.displayOperationNumber;

    const correctedLegacy = recordExpense(food, wallet, 250, "2026-09-15", "p1", true); // تغيير التاريخ أيضًا — يمكن أن يغيّر ترتيب رقم العرض المحسوب لو لم نُجمِّده
    const updatedLegacy = await repo.updateJournalEntryAndPersist(legacyEntry.id, correctedLegacy);
    assertEqual(updatedLegacy.operationNumber, displayBefore, "3-د: رقم العرض المحسوب للقيد القديم جُمِّد عند التعديل وبقي كما كان قبل تغيير التاريخ");
  }

  console.log("\n=== 4) تعديل عملية يعيد حساب الأرصدة والتقارير من البيانات الجديدة (بلا أي كاش قديم) ===\n");
  {
    const fs4 = require("fs"); if (fs4.existsSync(DB_FILE)) fs4.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.openPeriod({ id: "p1", startDate: "2026-09-01", endDate: "2026-09-30", status: "open" });

    const entry = recordIncome(salary, wallet, 1000, "2026-09-01", "p1");
    await repo.persistJournalEntry(entry);
    assertEqual(await repo.getAccountBalance(wallet.id), 1000, "4-أ (تمهيدي): الرصيد قبل التعديل = 1000");

    const corrected = recordIncome(salary, wallet, 4000, "2026-09-01", "p1"); // نفس الأطراف، مبلغ مصحَّح
    await repo.updateJournalEntryAndPersist(entry.id, corrected);
    assertEqual(await repo.getAccountBalance(wallet.id), 4000, "4-ب: الرصيد بعد التعديل = 4000 (يعكس المبلغ الجديد فورًا)");

    const entries = await repo.getAllJournalEntries();
    const realBalance = computeBalance(await storage.getAccount(wallet.id) as Account, entries);
    assertEqual(realBalance, 4000, "4-ج: يطابق computeBalance الحقيقية مباشرة من ledger.ts (غير معدَّلة)");

    const report = buildAccountLedgerReport({ account: wallet, allAccounts: [wallet, salary], entries });
    assertEqual(report.totals?.["الرصيد النهائي"], "4,000", "4-د: تقرير كشف الحساب يعكس المبلغ المُعدَّل تلقائيًا (بلا أي تغيير في reports.ts)");
    assertEqual(report.rows.length, 1, "4-هـ: سطر واحد فقط في التقرير (العملية القديمة استُبدلت، لا سطرين)");
  }

  console.log("\n=== 5) حذف عملية يعيد حساب الأرصدة والتقارير فورًا ===\n");
  {
    const fs5 = require("fs"); if (fs5.existsSync(DB_FILE)) fs5.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.saveAccount(food);
    await repo.openPeriod({ id: "p1", startDate: "2026-09-01", endDate: "2026-09-30", status: "open" });

    const e1 = recordIncome(salary, wallet, 5000, "2026-09-01", "p1");
    const e2 = recordExpense(food, wallet, 1200, "2026-09-02", "p1", true);
    await repo.persistJournalEntry(e1);
    await repo.persistJournalEntry(e2);
    assertEqual(await repo.getAccountBalance(wallet.id), 3800, "5-أ (تمهيدي): الرصيد قبل الحذف = 5000-1200 = 3800");

    await repo.deleteJournalEntryAndPersist(e2.id);
    assertEqual(await repo.getAccountBalance(wallet.id), 5000, "5-ب: الرصيد بعد حذف المصروف = 5000 فقط");
    assertEqual((await repo.getAllJournalEntries()).length, 1, "5-ج: عملية واحدة فقط متبقية في التخزين");

    const report = buildAccountLedgerReport({ account: wallet, allAccounts: [wallet, salary, food], entries: await repo.getAllJournalEntries() });
    assertEqual(report.rows.length, 1, "5-د: التقرير يعكس الحذف تلقائيًا (سطر واحد فقط)");
  }

  console.log("\n=== 6) منع التعديل والحذف في فترة مغلقة ===\n");
  {
    const fs6 = require("fs"); if (fs6.existsSync(DB_FILE)) fs6.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.openPeriod({ id: "p1", startDate: "2026-08-01", endDate: "2026-08-31", status: "open" });

    const entry = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
    await repo.persistJournalEntry(entry);

    assertTrue(await repo.isEntryEditable(entry.id), "6-أ: العملية قابلة للتعديل ما دامت فترتها مفتوحة");

    // إغلاق الفترة فعليًا (نفس مسار الإغلاق الحقيقي المستخدَم في التطبيق)
    await repo.closePeriodAndPersist("p1", "p2", [{ account: salary, approvedAmount: 1000, actualAmount: 1000 }], { startDate: "2026-09-01", endDate: "2026-09-30" });

    assertTrue(!(await repo.isEntryEditable(entry.id)), "6-ب: بعد إغلاق الفترة — العملية لم تعد قابلة للتعديل");

    const corrected = recordIncome(salary, wallet, 2000, "2026-08-01", "p1");
    await assertRejects(() => repo.updateJournalEntryAndPersist(entry.id, corrected), ClosedPeriodEditError, "6-ج: محاولة تعديل عملية بفترة مغلقة تُرفَض بخطأ واضح");
    await assertRejects(() => repo.deleteJournalEntryAndPersist(entry.id), ClosedPeriodEditError, "6-د: محاولة حذف عملية بفترة مغلقة تُرفَض بخطأ واضح");

    assertEqual(await repo.getAccountBalance(wallet.id), 1000, "6-هـ: الرصيد لم يتغيّر بعد كل محاولات التعديل/الحذف المرفوضة");
    const stillThere = await repo.getJournalEntry(entry.id);
    assertTrue(stillThere !== null && stillThere.lines.some((l) => l.amount === 1000), "6-و: القيد الأصلي لم يُمسّ إطلاقًا (لا تعديل جزئي ولا حذف)");
  }

  console.log("\n=== 7) تعديل/حذف معرّف عملية غير موجود يُرفَض بوضوح ===\n");
  {
    const fs7 = require("fs"); if (fs7.existsSync(DB_FILE)) fs7.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const fakeEntry = recordIncome(salary, wallet, 100, "2026-09-01", "p1");
    await assertRejects(() => repo.updateJournalEntryAndPersist("je_not_real", fakeEntry), JournalEntryNotFoundError, "7-أ: تعديل معرّف غير موجود يُرفَض بخطأ واضح");
    await assertRejects(() => repo.deleteJournalEntryAndPersist("je_not_real"), JournalEntryNotFoundError, "7-ب: حذف معرّف غير موجود يُرفَض بخطأ واضح");
  }

  console.log("\n=== 8) getAccountBalanceExcludingEntry: تحقق صحيح للرصيد عند تعديل مصروف/سداد دين ===\n");
  {
    const fs8 = require("fs"); if (fs8.existsSync(DB_FILE)) fs8.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const w = acc("acc_w8", "محفظة", "pot");
    await repo.saveAccount(w);
    await repo.saveAccount(salary);
    await repo.saveAccount(food);
    await repo.openPeriod({ id: "p1", startDate: "2026-09-01", endDate: "2026-09-30", status: "open" });

    await repo.persistJournalEntry(recordIncome(salary, w, 1000, "2026-09-01", "p1"));
    const oldExpense = recordExpense(food, w, 300, "2026-09-02", "p1", true);
    await repo.persistJournalEntry(oldExpense);
    // الرصيد الحالي = 1000 - 300 = 700 (يتضمَّن أثر oldExpense)
    assertEqual(await repo.getAccountBalance(w.id), 700, "8-أ (تمهيدي): الرصيد الحالي = 700");

    const excluding = await repo.getAccountBalanceExcludingEntry(w.id, oldExpense.id);
    assertEqual(excluding, 1000, "8-ب: الرصيد باستثناء المصروف القديم = 1000 (كما لو لم يُسجَّل بعد) — يسمح بتحقق حد صحيح عند تعديله لمبلغ أكبر لا يتجاوز 1000");

    const notExcluding = await repo.getAccountBalance(w.id);
    assertEqual(notExcluding, 700, "8-ج: getAccountBalance العادية لم تتأثر — القراءتان مستقلتان تمامًا");
  }

  console.log("\n=== 9) تعديل قيد مباشر: نفس تحقق توافق العملة المطبَّق على الإنشاء بالضبط ===\n");
  {
    const fs9 = require("fs"); if (fs9.existsSync(DB_FILE)) fs9.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const debtA = acc("acc_debtA", "دين أ", "one_time_debt");
    const debtB = acc("acc_debtB", "دين ب", "one_time_debt");
    const debtC = acc("acc_debtC", "دين ج", "one_time_debt");
    await repo.saveAccount(debtA);
    await repo.saveAccount(debtB);
    await repo.saveAccount(debtC);
    await repo.openPeriod({ id: "p1", startDate: "2026-09-01", endDate: "2026-09-30", status: "open" });
    await repo.addCurrency({ code: "SAR", name: "ريال سعودي", symbol: "ر.س" });
    await repo.addCurrency({ code: "YER", name: "ريال يمني", symbol: "﷼" });
    await repo.saveAccountCurrencyLink({ accountId: debtA.id, currencyCode: "SAR" });
    await repo.saveAccountCurrencyLink({ accountId: debtB.id, currencyCode: "SAR" });
    await repo.saveAccountCurrencyLink({ accountId: debtC.id, currencyCode: "YER" });

    const entry = await repo.recordDirectEntryAndPersist(debtA.id, debtB.id, 500, "2026-09-01", "p1", "تسوية");
    const updated = await repo.updateDirectEntryAndPersist(entry.id, debtA.id, debtB.id, 700, "2026-09-02", "تسوية معدَّلة");
    assertEqual(updated.lines.find((l) => l.direction === "DEBIT")?.amount, 700, "9-أ: تعديل قيد مباشر بنفس عملة الطرفين ينجح ويطبِّق المبلغ الجديد");

    await assertRejects(
      () => repo.updateDirectEntryAndPersist(entry.id, debtA.id, debtC.id, 700, "2026-09-02", "محاولة عبر عملتين مختلفتين"),
      Error,
      "9-ب: تعديل قيد مباشر إلى حسابين بعملتين مختلفتين يُرفَض (نفس قاعدة الإنشاء تمامًا)"
    );
  }

  console.log("\n=== 10) لا مسار صامت يتجاوز الفحوصات — updateJournalEntryAndPersist تتحقق من الفترة حتى لو لم يُستدعَ isEntryEditable أولًا ===\n");
  {
    const fs10 = require("fs"); if (fs10.existsSync(DB_FILE)) fs10.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.openPeriod({ id: "p1", startDate: "2026-08-01", endDate: "2026-08-31", status: "open" });
    const entry = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
    await repo.persistJournalEntry(entry);
    await repo.closePeriodAndPersist("p1", "p2", [{ account: salary, approvedAmount: 1000, actualAmount: 1000 }], { startDate: "2026-09-01", endDate: "2026-09-30" });

    // بلا استدعاء isEntryEditable إطلاقًا — الفحص الحقيقي يجب أن يحدث داخل updateJournalEntryAndPersist نفسها
    await assertRejects(
      () => repo.updateJournalEntryAndPersist(entry.id, recordIncome(salary, wallet, 9999, "2026-08-01", "p1")),
      ClosedPeriodEditError,
      "10-أ: الفحص يحدث داخل الدالة نفسها بغضّ النظر عن استدعاء isEntryEditable مسبقًا أم لا"
    );
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات تعديل وحذف العمليات (الملاحظة 4): ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  const fsFinal = require("fs");
  if (fsFinal.existsSync(DB_FILE)) fsFinal.unlinkSync(DB_FILE);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات التعديل/الحذف:", e);
  process.exit(1);
});
