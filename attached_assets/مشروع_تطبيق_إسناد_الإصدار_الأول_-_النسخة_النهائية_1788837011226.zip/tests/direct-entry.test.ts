// ============================================================
// اختبارات ميزة "القيد المباشر بين حسابين" (Direct Entry) — المرحلة الثانية.
// تغطي 15 حالة المطلوبة في مواصفة المرحلة. الحالتان 1 و2 (ظهور الخيار في الواجهة،
// وعدم ظهور حقل الوعاء) تُفحصان هنا فحصًا نصيًا ثابتًا على مصدر web/app.ts، لأن بيئة
// اختبار Node هذه بلا DOM حقيقي — وهو نفس القيد الموثَّق أصلًا في الكود لاختبارات
// IndexedDBStorageAdapter (يحتاج متصفحًا حقيقيًا). بقية الحالات (3–15) تُختبر فعليًا
// عبر transactions.ts/Repository دون أي محاكاة.
// ============================================================
import { Account } from "../src/types";
import { recordDirectEntry, recordIncome, recordExpense, recordTransfer, recordRecurringDebtPayment } from "../src/transactions";
import { computeBalance, InvalidAmountError } from "../src/ledger";
import { FileStorageAdapter } from "../src/storage";
import { Repository } from "../src/repository";
import { Currency } from "../src/currency";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
async function assertRejects(fn: () => Promise<unknown> | unknown, label: string) {
  try {
    await fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يُرفَض ولم يُرفَض`);
  } catch {
    passed++; console.log(`✅ ${label}`);
  }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;
declare const __dirname: string;
const DB_FILE = "/tmp/isnad_test_direct_entry_db.json";

async function main() {
  const fs = require("fs");

  console.log("=== 1–2) فحص ثابت على مصدر الواجهة: ظهور \"قيد مباشر\" وعدم ظهور حقل الوعاء ضمنه ===\n");
  {
    const path = require("path");
    const appTsPath = path.join(__dirname, "..", "..", "web", "app.ts");
    const src: string = fs.readFileSync(appTsPath, "utf-8");

    assertTrue(/<option value="direct_entry"[^>]*>قيد مباشر<\/option>/.test(src), "1: خيار \"قيد مباشر\" مضاف فعليًا لقائمة نوع العملية في web/app.ts");

    // نعزل كتلة حقول direct_entry تحديدًا (بين "direct_entry\") {" و الفرع التالي) للتأكد أنها لا تحتوي على tx-pot
    const blockStart = src.indexOf(`t === "direct_entry"`);
    assertTrue(blockStart !== -1, "1-ب: كتلة حقول direct_entry موجودة في renderFields()");
    const blockEnd = src.indexOf("}\n  }", blockStart); // نهاية دالة renderFields بعد آخر else-if
    const block = src.slice(blockStart, blockEnd === -1 ? blockStart + 1200 : blockEnd);
    assertTrue(!block.includes(`id="tx-pot"`), "2: حقل \"الوعاء\" (tx-pot) لا يظهر إطلاقًا داخل كتلة حقول القيد المباشر");
    assertTrue(block.includes(`id="tx-direct-debit"`) && block.includes(`id="tx-direct-credit"`), "2-ب: حقلا الحساب المدين والدائن (اختيار من كل الحسابات) موجودان بدلًا من الوعاء");
  }

  console.log("\n=== 3–6) سيناريوهات القيد المباشر بمبالغ محددة (مصروف↔دين، دين↔دين، دين↔وعاء، وعاء↔مصروف) ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const houseExpense = acc("acc_house_exp", "مصروف البيت", "expense");
    const debtA = acc("acc_debt_a", "الدين المستمر الأول", "recurring_debt");
    const debtB = acc("acc_debt_b", "الدين المستمر الثاني", "recurring_debt");
    const oneTimeDebt = acc("acc_once_debt", "دين لمرة واحدة", "one_time_debt");
    const wallet = acc("acc_wallet", "الصندوق", "pot");
    for (const a of [houseExpense, debtA, debtB, oneTimeDebt, wallet]) await repo.saveAccount(a);

    // 3: مصروف البيت مدين 500 ← الدين المستمر الأول دائن 500
    await repo.recordDirectEntryAndPersist(houseExpense.id, debtA.id, 500, "2026-08-01", "p1");
    assertEqual(await repo.getAccountBalance(houseExpense.id), 500, "3-أ: رصيد مصروف البيت (مدين) = 500");
    assertEqual(await repo.getAccountBalance(debtA.id), 500, "3-ب: رصيد الدين المستمر الأول (دائن/التزام) = 500");

    // 4: الدين المستمر الأول مدين 1000 ← الدين المستمر الثاني دائن 1000
    await repo.recordDirectEntryAndPersist(debtA.id, debtB.id, 1000, "2026-08-02", "p1");
    assertEqual(await repo.getAccountBalance(debtA.id), -500, "4-أ: رصيد الدين الأول بعد مدين 1000 (500-1000) = -500");
    assertEqual(await repo.getAccountBalance(debtB.id), 1000, "4-ب: رصيد الدين الثاني (دائن) = 1000");

    // 5: دين لمرة واحدة مدين 500 ← الصندوق دائن 500
    // تدبيث حساب الالتزام (دين، طبيعته الدائنة) يُخفِّضه — نفس منطق computeBalance غير المعدَّل:
    // balance = opening + creditSum − debitSum لحسابات الالتزام، فمدين 500 بلا دائن سابق = −500.
    await repo.recordDirectEntryAndPersist(oneTimeDebt.id, wallet.id, 500, "2026-08-03", "p1");
    assertEqual(await repo.getAccountBalance(oneTimeDebt.id), -500, "5-أ: تدبيث الدين لمرة واحدة يخفِّض التزامه إلى -500 (منطق computeBalance الأصلي دون تعديل)");
    assertEqual(await repo.getAccountBalance(wallet.id), -500, "5-ب: رصيد الصندوق (دائن يخفّض الأصل) = -500");

    // 6: الصندوق مدين 200 ← مصروف البيت دائن 200
    await repo.recordDirectEntryAndPersist(wallet.id, houseExpense.id, 200, "2026-08-04", "p1");
    assertEqual(await repo.getAccountBalance(wallet.id), -300, "6-أ: رصيد الصندوق بعد مدين 200 (-500+200) = -300");
    assertEqual(await repo.getAccountBalance(houseExpense.id), 300, "6-ب: رصيد مصروف البيت بعد دائن 200 (500-200) = 300");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 7) رفض اختيار نفس الحساب للطرفين ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const wallet = acc("acc_wallet", "الصندوق", "pot");
    await repo.saveAccount(wallet);
    await assertRejects(
      () => repo.recordDirectEntryAndPersist(wallet.id, wallet.id, 100, "2026-08-05", "p1"),
      "7: رفض قيد مباشر بنفس الحساب مدينًا ودائنًا"
    );
    assertEqual((await repo.getAllJournalEntries()).length, 0, "7-ب: القيد المرفوض لم يُحفَظ إطلاقًا");
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 8) رفض مبلغ صفر أو سالب ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const a = acc("acc_a", "أ", "pot");
    const b = acc("acc_b", "ب", "expense");
    await repo.saveAccount(a);
    await repo.saveAccount(b);
    await assertRejects(() => repo.recordDirectEntryAndPersist(a.id, b.id, 0, "2026-08-05", "p1"), "8-أ: رفض مبلغ = 0");
    await assertRejects(() => repo.recordDirectEntryAndPersist(a.id, b.id, -50, "2026-08-05", "p1"), "8-ب: رفض مبلغ سالب (-50)");
    // يتأكد أن الرافض تحديدًا هو نفس تحقق ledger.ts القياسي (InvalidAmountError) ولم يُضَف تحقق مواز مختلف
    try {
      recordDirectEntry(a, b, 0, "2026-08-05", "p1");
      assertTrue(false, "8-ج: recordDirectEntry(0) كان يجب أن يرمي InvalidAmountError");
    } catch (e) {
      assertTrue(e instanceof InvalidAmountError, "8-ج: recordDirectEntry(0) يرمي InvalidAmountError من ledger.ts نفسه (لا تحقق منفصل جديد)");
    }
    assertEqual((await repo.getAllJournalEntries()).length, 0, "8-د: لا قيود رُفضت تسرَّبت إلى التخزين");
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 9) رفض حسابين بعملتين مختلفتين (لا يوجد FX) ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const sar: Currency = { code: "SAR", name: "ريال سعودي", symbol: "ر.س" };
    const usd: Currency = { code: "USD", name: "دولار أمريكي", symbol: "$" };
    await repo.saveCurrency(sar);
    await repo.saveCurrency(usd);

    const walletSar = acc("acc_wallet_sar", "محفظة بالريال", "pot");
    const expenseUsd = acc("acc_exp_usd", "مصروف بالدولار", "expense");
    await repo.saveAccount(walletSar);
    await repo.saveAccount(expenseUsd);
    await repo.saveAccountCurrencyLink({ accountId: walletSar.id, currencyCode: "SAR" });
    await repo.saveAccountCurrencyLink({ accountId: expenseUsd.id, currencyCode: "USD" });

    await assertRejects(
      () => repo.recordDirectEntryAndPersist(expenseUsd.id, walletSar.id, 100, "2026-08-06", "p1"),
      "9-أ: رفض قيد مباشر بين حساب بالريال وحساب بالدولار"
    );
    assertEqual((await repo.getAllJournalEntries()).length, 0, "9-ب: القيد المرفوض بسبب اختلاف العملة لم يُحفَظ");

    // نفس العملة صراحة → يُقبَل بلا مشكلة (تأكيد أن الرفض بسبب الاختلاف تحديدًا لا خلل عام)
    const walletSar2 = acc("acc_wallet_sar2", "محفظة أخرى بالريال", "pot");
    await repo.saveAccount(walletSar2);
    await repo.saveAccountCurrencyLink({ accountId: walletSar2.id, currencyCode: "SAR" });
    await repo.recordDirectEntryAndPersist(walletSar.id, walletSar2.id, 50, "2026-08-06", "p1");
    assertEqual((await repo.getAllJournalEntries()).length, 1, "9-ج: قيد مباشر بنفس العملة (ريال↔ريال) يُقبَل ويُحفَظ بنجاح");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 10–11) ظهور القيد في سجل العمليات وصحة الأرصدة بعده ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const a = acc("acc_a", "حساب أ", "pot");
    const b = acc("acc_b", "حساب ب", "expense");
    await repo.saveAccount(a);
    await repo.saveAccount(b);
    const entry = await repo.recordDirectEntryAndPersist(a.id, b.id, 777, "2026-08-07", "p1", "وصف اختياري");

    const all = await repo.getAllJournalEntries();
    assertEqual(all.length, 1, "10-أ: القيد المباشر ظهر في سجل كل القيود (getAllJournalEntries)");
    assertEqual(all[0].id, entry.id, "10-ب: القيد المخزَّن هو نفس القيد المُنشأ (نفس المعرّف)");
    assertEqual(all[0].transactionType, "direct_entry", "10-ج: نوع العملية المحفوظ = direct_entry");
    assertEqual(all[0].description, "وصف اختياري", "10-د: الوصف الاختياري محفوظ كما أُدخل");

    assertEqual(await repo.getAccountBalance(a.id), 777, "11-أ: رصيد الحساب المدين تأثر بشكل صحيح (+777)");
    // b من فئة "مصروف" (طبيعته مدينة) — تدبيثه بـ 777 يُخفِّض رصيده إلى -777 عبر نفس computeBalance
    // الأصلي غير المعدَّل (opening + debitSum − creditSum)، وهو الأثر المحاسبي الصحيح لقيد دائن على حساب مدين الطبيعة.
    assertEqual(await repo.getAccountBalance(b.id), -777, "11-ب: رصيد الحساب الدائن (فئة مصروف) تأثر بشكل صحيح (-777 عبر منطق computeBalance الأصلي)");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 12) العمليات القديمة (دخل/مصروف/سداد دين) تعمل دون أي تغيير في سلوكها ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    const food = acc("acc_food", "طعام", "expense");
    const debt = acc("acc_debt", "دين مستمر", "recurring_debt");
    for (const a of [wallet, salary, food, debt]) await repo.saveAccount(a);

    await repo.persistJournalEntry(recordIncome(salary, wallet, 10000, "2026-08-08", "p1"));
    assertEqual(await repo.getAccountBalance(wallet.id), 10000, "12-أ: recordIncome يعمل كما هو تمامًا بعد إضافة القيد المباشر");

    await repo.persistJournalEntry(recordExpense(food, wallet, 2000, "2026-08-08", "p1", false, await repo.getAccountBalance(wallet.id)));
    assertEqual(await repo.getAccountBalance(wallet.id), 8000, "12-ب: recordExpense يعمل كما هو تمامًا");

    await repo.persistJournalEntry(recordRecurringDebtPayment(debt, wallet, 1000, "2026-08-08", "p1"));
    assertEqual(await repo.getAccountBalance(wallet.id), 7000, "12-ج: recordRecurringDebtPayment يعمل كما هو تمامًا");
    assertEqual(await repo.getAccountBalance(debt.id), -1000, "12-د: رصيد الدين بعد السداد صحيح (لم يتأثر منطقه)");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 13) استمرار \"تحويل بين أوعية\" (Transfer) دون أي تغيير ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const potA = acc("acc_pot_a", "وعاء أ", "pot");
    const potB = acc("acc_pot_b", "وعاء ب", "pot");
    await repo.saveAccount(potA);
    await repo.saveAccount(potB);
    await repo.persistJournalEntry(recordTransfer(potA, potB, 3000, "2026-08-09", "p1"));
    // recordTransfer نفسه يمنع نفس الوعاء عبر assertAccountCategory + منطق الواجهة، ونتحقق هنا فقط من الأثر المحاسبي
    assertEqual(await repo.getAccountBalance(potA.id), -3000, "13-أ: التحويل يخفِّض رصيد الوعاء المصدر كالمعتاد تمامًا");
    assertEqual(await repo.getAccountBalance(potB.id), 3000, "13-ب: التحويل يزيد رصيد الوعاء الوجهة كالمعتاد تمامًا");
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 14) استمرار القيد المباشر بعد \"إعادة تشغيل\" فعلية (Offline First) ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage1 = new FileStorageAdapter(DB_FILE);
    const repo1 = new Repository(storage1);
    const a = acc("acc_a", "أ", "pot");
    const b = acc("acc_b", "ب", "expense");
    await repo1.saveAccount(a);
    await repo1.saveAccount(b);
    await repo1.recordDirectEntryAndPersist(a.id, b.id, 4321, "2026-08-10", "p1");

    // --- محاكاة إغلاق التطبيق وإعادة فتحه: كائنات جديدة تمامًا تقرأ نفس الملف من القرص ---
    const storage2 = new FileStorageAdapter(DB_FILE);
    const repo2 = new Repository(storage2);
    const reloadedEntries = await repo2.getAllJournalEntries();
    assertEqual(reloadedEntries.length, 1, "14-أ: القيد المباشر عاد من القرص بعد إعادة التشغيل");
    assertEqual(reloadedEntries[0].transactionType, "direct_entry", "14-ب: نوعه (direct_entry) عاد صحيحًا");
    assertEqual(await repo2.getAccountBalance(a.id), 4321, "14-ج: رصيد الحساب المدين صحيح بعد إعادة التحميل من القرص");
    assertEqual(await repo2.getAccountBalance(b.id), -4321, "14-د: رصيد الحساب الدائن (فئة مصروف) صحيح بعد إعادة التحميل من القرص (-4321 عبر منطق computeBalance الأصلي)");
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log("\n=== 15) لا قيود غير متوازنة أو مرفوضة تتسرّب إلى التخزين — طبقة الحماية المضاعفة تعمل أيضًا للقيد المباشر ===\n");
  {
    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);
    const a = acc("acc_a", "أ", "pot");
    const b = acc("acc_b", "ب", "expense");
    await repo.saveAccount(a);
    await repo.saveAccount(b);

    // محاولة حفظ قيد مباشر "يدويًا" غير متوازن مباشرةً عبر storage.appendJournalEntry (تجاوز recordDirectEntry تمامًا)
    // يجب أن تُرفَض من نفس طبقة الحماية المضاعفة في storage.ts (assertBalanced) المستخدَمة لكل الأنواع الأخرى.
    await assertRejects(
      () =>
        storage.appendJournalEntry({
          id: "je_bad_direct",
          entryDate: "2026-08-11",
          transactionType: "direct_entry",
          periodId: "p1",
          lines: [
            { accountId: a.id, direction: "DEBIT", amount: 500 },
            { accountId: b.id, direction: "CREDIT", amount: 400 },
          ],
        }),
      "15-أ: محاولة حفظ قيد مباشر غير متوازن مباشرة عبر التخزين تُرفَض (بلا مرور عبر recordDirectEntry أصلًا)"
    );
    assertEqual((await repo.getAllJournalEntries()).length, 0, "15-ب: القيد غير المتوازن لم يظهر إطلاقًا في القيود المحفوظة");

    // ونفس النتيجة عبر المسار الطبيعي الكامل (Repository.recordDirectEntryAndPersist) عند اختلاف العملة (سبق اختباره في §9)
    // — هنا فقط نؤكد أن العدد ما زال صفرًا بعد كل محاولات الرفض السابقة في هذا القسم
    await assertRejects(() => repo.recordDirectEntryAndPersist(a.id, a.id, 10, "2026-08-11", "p1"), "15-ج: محاولة أخرى مرفوضة (نفس الحساب) لا تُسجَّل أيضًا");
    assertEqual((await repo.getAllJournalEntries()).length, 0, "15-د: لا شيء تسرَّب إلى IndexedDB/التخزين من أي محاولة مرفوضة");

    if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات القيد المباشر: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات القيد المباشر:", e);
  process.exit(1);
});
