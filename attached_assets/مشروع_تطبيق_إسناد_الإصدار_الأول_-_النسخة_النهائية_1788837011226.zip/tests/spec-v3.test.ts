// ============================================================
// اختبارات المواصفة v3 — تُكتَب ضد القواعد المعتمَدة، وليس ضد سلوك الكود الحالي.
// يُتوقَّع فشل بعضها (أو فشل الترجمة) قبل تعديل src/*.ts — هذا هو الغرض من الخطوة.
// ============================================================
import { Account } from "../src/types";
import { runDistribution, DistributionInput } from "../src/distribution";
import { determineStage, forcedPaydown, reduceMinThenBalance, RecurringDebtState } from "../src/recurringDebt";

let passed = 0;
let failed = 0;
const failures: string[] = [];

function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else {
    failed++;
    const msg = `❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`;
    console.log(msg);
    failures.push(label);
  }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); failures.push(label); }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}
function round2(n: number): number { return Math.round((n + Number.EPSILON) * 100) / 100; }

const food = acc("exp_food", "طعام", "expense");
const rent = acc("exp_rent", "إيجار", "expense");
const elec = acc("exp_elec", "كهرباء", "expense");
const water = acc("exp_water", "ماء", "expense");
const goalA = acc("goal_a", "هدف أ", "goal");
const goalB = acc("goal_b", "هدف ب", "goal");
const debtOnce = acc("debt_once", "دين لمرة واحدة", "one_time_debt");
const debtOnce2 = acc("debt_once2", "دين لمرة واحدة 2", "one_time_debt");
const rdebt = acc("rdebt", "دين مستمر", "recurring_debt");
const rdebt2 = acc("rdebt2", "دين مستمر 2", "recurring_debt");
const reserve = acc("reserve", "احتياطي", "reserve");

console.log("========== 1) Conservation of Money ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 87345,
    expenses: [
      { account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high", carriedDeficit: 1234 },
      { account: elec, monthlyMin: 5000, monthlyMax: 9000, priority: "essential" },
    ],
    goals: [
      { account: goalA, minAllocation: 6000, maxAllocation: 20000, targetAmount: 100000, achievedAmount: 0, priority: "critical", carriedDeficit: 2000 },
    ],
    oneTimeDebts: [{ account: debtOnce, remainingBalance: 8000, priority: "urgent" }],
    recurringDebts: [{ account: rdebt, currentBalance: 42000, minLimit: 10000, maxLimit: 50000 }],
    reserve: { account: reserve },
  };
  const r = runDistribution(input);
  const totalAllocated = round2(r.allocations.reduce((s, a) => s + a.amount, 0));
  assertEqual(round2(totalAllocated + r.remainingAfterAllStages), input.incomeAvailable, "1-أ: مجموع كل التخصيصات + المتبقي = الدخل المتاح تمامًا (لا فقدان ولا اختلاق أموال)");
}

console.log("\n========== 2) عدم استدعاء ledger.ts/transactions.ts من محرك التوزيع ==========\n");
{
  // اختبار بنيوي: التحقق أن runDistribution لا تأخذ أي مرجع لدفتر أو تُرجع أي كائن من نوع JournalEntry
  const input: DistributionInput = {
    periodId: "p", incomeAvailable: 50000,
    expenses: [{ account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high" }],
    goals: [], oneTimeDebts: [], recurringDebts: [],
  };
  const r = runDistribution(input);
  assertTrue(!("journalEntryId" in (r as any)) && r.allocations.every((a) => !("journalEntryId" in (a as any))), "2-أ: لا يوجد أي حقل journalEntryId في أي مخرَج — Planned منفصل بنيويًا عن Actual");
}

console.log("\n========== 3) تقرير نقص الدخل التفصيلي (§10) ==========\n");
{
  const input: DistributionInput = {
    periodId: "p", incomeAvailable: 20000,
    expenses: [
      { account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high", dueDate: "2026-09-01" },
      { account: rent, monthlyMin: 15000, monthlyMax: 15000, priority: "essential_high" },
    ],
    goals: [], oneTimeDebts: [], recurringDebts: [],
  };
  const r = runDistribution(input);
  assertTrue(r.insufficientAllocationReport !== undefined, "3-أ: يوجد تقرير نقص عند عدم كفاية الدخل");
  if (r.insufficientAllocationReport) {
    const rep = r.insufficientAllocationReport;
    assertEqual(rep.totalRequired, 25000, "3-ب: totalRequired = 25,000");
    assertEqual(rep.totalFunded, 20000, "3-ج: totalFunded = 20,000 (كل الدخل استُهلك)");
    assertEqual(rep.totalUnfunded, 5000, "3-د: totalUnfunded = 5,000");
    const foodLine = rep.perAccount.find((x) => x.accountId === food.id);
    const rentLine = rep.perAccount.find((x) => x.accountId === rent.id);
    assertTrue(!!foodLine && !!rentLine, "3-هـ: كل حساب له سطر مستقل في التقرير");
    assertEqual(foodLine?.priority, "essential_high", "3-و: يحمل السطر أولوية الحساب");
    assertEqual(foodLine?.dueDate, "2026-09-01", "3-ز: يحمل السطر تاريخ الاستحقاق إن وُجد");
    assertTrue((foodLine?.remaining ?? 0) >= 0 && (rentLine?.remaining ?? 0) >= 0, "3-ح: remaining محسوبة لكل حساب");
    assertTrue(!!foodLine?.reasonNotFunded || foodLine!.remaining === 0, "3-ط: سبب نصي عند وجود نقص");
  }
}

console.log("\n========== 4) تعادل الأولوية — استقلالية النتيجة عن ترتيب الإدخال ==========\n");
{
  const base = (order: "AB" | "BA"): DistributionInput => ({
    periodId: "p",
    incomeAvailable: 3000, // يكفي عجزًا واحدًا فقط من الاثنين (كلاهما 3,000، أولوية متساوية، بلا تاريخ استحقاق)
    expenses: [],
    goals:
      order === "AB"
        ? [
            { account: goalA, minAllocation: 0, maxAllocation: 0, targetAmount: 100000, achievedAmount: 0, priority: "moderate", carriedDeficit: 3000 },
            { account: goalB, minAllocation: 0, maxAllocation: 0, targetAmount: 100000, achievedAmount: 0, priority: "moderate", carriedDeficit: 3000 },
          ]
        : [
            { account: goalB, minAllocation: 0, maxAllocation: 0, targetAmount: 100000, achievedAmount: 0, priority: "moderate", carriedDeficit: 3000 },
            { account: goalA, minAllocation: 0, maxAllocation: 0, targetAmount: 100000, achievedAmount: 0, priority: "moderate", carriedDeficit: 3000 },
          ],
    oneTimeDebts: [],
    recurringDebts: [],
  });
  const r1 = runDistribution(base("AB"));
  const r2 = runDistribution(base("BA"));
  const alloc1 = r1.allocations.filter((a) => a.stage === 0).map((a) => ({ id: a.accountId, amt: a.amount }));
  const alloc2 = r2.allocations.filter((a) => a.stage === 0).map((a) => ({ id: a.accountId, amt: a.amount }));
  assertEqual(alloc1, alloc2, "4-أ: نفس النتيجة تمامًا بصرف النظر عن ترتيب goalA/goalB في مصفوفة الإدخال (الفاصل الحتمي accountId يحسم التعادل)");
  assertEqual(alloc1.find((a) => a.id === goalA.id)?.amt, 3000, "4-ب: goal_a (أبجديًا قبل goal_b) يحصل على كامل المبلغ المتاح عند التعادل التام");
  assertEqual(alloc1.find((a) => a.id === goalB.id)?.amt ?? 0, 0, "4-ج: goal_b لا يحصل على شيء (نفد المتاح عند goal_a)");
}

console.log("\n========== 5) عدة ديون مستمرة تتنافس على فائض Stage 6ب واحد (نفس منطق المثال المعتمَد، مطبَّق تسلسليًا) ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 15000,
    expenses: [], goals: [], oneTimeDebts: [],
    recurringDebts: [
      { account: rdebt, currentBalance: 8000, minLimit: 8000, maxLimit: 50000 }, // بالضبط عند الحد الأدنى
      { account: rdebt2, currentBalance: 5000, minLimit: 5000, maxLimit: 30000 }, // بالضبط عند الحد الأدنى
    ],
  };
  const r = runDistribution(input);
  // الترتيب الحتمي بالمعرّف: "rdebt" < "rdebt2" أبجديًا → rdebt يُعالَج أولًا بكامل الفائض المتاح (15,000)،
  // وفق نفس صيغة المثال المعتمَد (§16 مثال ب): يُستهلَك تخفيض الحد الأدنى أولًا، ثم يُكمَل الباقي لتخفيض الرصيد لنفس الحساب
  // قبل الانتقال للحساب التالي في الطابور — لا يُترَك للحساب التالي إلا ما تبقّى فعليًا بعد ذلك.
  const rdebtNote = r.recurringDebtResults.find((n) => n.accountId === rdebt.id);
  const rdebt2Note = r.recurringDebtResults.find((n) => n.accountId === rdebt2.id);
  assertEqual(rdebtNote?.reducedMinLimitBy, 8000, "5-أ: rdebt يستهلك 8,000 لتصفير حده الأدنى بالكامل (أول من في الطابور)");
  assertEqual(rdebtNote?.reducedBalanceBy, 7000, "5-ب: الباقي من نصيب rdebt نفسه (15,000-8,000=7,000) يكمل مباشرة لتخفيض رصيده هو (لا ينتقل لحساب آخر ما دام لا يزال مؤهَّلًا) → رصيده الجديد 1,000");
  assertEqual(rdebt2Note?.reducedMinLimitBy ?? 0, 0, "5-ج: لم يتبقَّ أي فائض لـ rdebt2 — استُهلك بالكامل في دور rdebt");
  assertEqual(rdebt2Note?.reducedBalanceBy ?? 0, 0, "5-د: ولا لتخفيض رصيده");
}

console.log("\n========== 6) دين لمرة واحدة أعلى أولوية يُستنفَد قبل وصول Stage 6 ==========\n");
{
  const flat = [{ account: food, monthlyMin: 10000, monthlyMax: 10000, priority: "essential_high" as const }];
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 10000 + 6000,
    expenses: flat, goals: [],
    oneTimeDebts: [{ account: debtOnce, remainingBalance: 6000, priority: "urgent_high" }],
    recurringDebts: [{ account: rdebt, currentBalance: 3000, minLimit: 3000, maxLimit: 50000 }],
  };
  const r = runDistribution(input);
  const debtAlloc = r.allocations.filter((a) => a.accountId === debtOnce.id).reduce((s, a) => s + a.amount, 0);
  const rdebtNote = r.recurringDebtResults.find((n) => n.accountId === rdebt.id);
  assertEqual(debtAlloc, 6000, "6-أ: الدين لمرة واحدة (Stage 5) يُموَّل بالكامل قبل وصول أي مبلغ لـ Stage 6");
  assertEqual((rdebtNote?.reducedMinLimitBy ?? 0) + (rdebtNote?.reducedBalanceBy ?? 0), 0, "6-ب: لا شيء يتبقى للدين المستمر بعد استنفاد Stage 5 بالكامل");
}

console.log("\n========== 7) عدم كفاية الدخل حتى لتغطية Stage 0 نفسها (يكشف خطأ ج-3 القديم) ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 4000, // أقل من عجز Stage0 نفسه (5,000+3,000=8,000)
    expenses: [
      { account: food, monthlyMin: 10000, monthlyMax: 15000, priority: "essential_high", carriedDeficit: 5000 },
    ],
    goals: [{ account: goalA, minAllocation: 5000, maxAllocation: 5000, targetAmount: 50000, achievedAmount: 0, priority: "critical", carriedDeficit: 3000 }],
    oneTimeDebts: [], recurringDebts: [],
  };
  const r = runDistribution(input);
  assertTrue(r.insufficientAllocationReport !== undefined, "7-أ: تقرير نقص يظهر حتى عند فشل تغطية Stage 0 نفسها");
  const rep = r.insufficientAllocationReport!;
  // Stage0: عجز الطعام (essential_high) قبل عجز الهدف؟ المجموعات: 0.1 مصروفات أولًا، فيُموَّل عجز الطعام أولًا (4,000 من أصل 5,000)
  const foodDeficitLine = rep.perAccount.find((x) => x.accountId === food.id);
  assertEqual(foodDeficitLine?.carriedDeficit, 5000, "7-ب: عجز الطعام المرحّل مسجَّل بكامل قيمته (5,000) في التقرير");
  assertEqual(foodDeficitLine?.funded, 4000, "7-ج: المموَّل فعليًا من عجز الطعام = 4,000 فقط (كل الدخل المتاح)، وليس أكثر");
  assertEqual(rep.totalFunded, 4000, "7-د: totalFunded الكلي = 4,000 (وليس صفرًا أو رقمًا وهميًا)");
  // تصحيح حسابي: totalRequired = food(monthlyMin 10,000 + carriedDeficit 5,000 = 15,000) + goalA(carriedDeficit فقط 3,000 — minAllocation لا يدخل هنا لأن الهدف ليس isNonDeferrable ولم تُبلَغ Stage2 أصلًا) = 18,000
  assertEqual(rep.totalUnfunded, round2(10000 + 5000 + 3000 - 4000), "7-هـ: totalUnfunded محسوب من التخصيص الفعلي في Stage0 لا من الاحتياج الكامل (تصحيح ج-3) = 14,000");
}

console.log("\n========== 8) اختبار توثيقي: لا رفع لأي هدف فوق minAllocation تحت أي ظرف ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 500000, // فائض ضخم متعمَّد
    expenses: [], oneTimeDebts: [], recurringDebts: [],
    goals: [{ account: goalA, minAllocation: 5000, maxAllocation: 999999, targetAmount: 1000000, achievedAmount: 0, priority: "critical" }],
  };
  const r = runDistribution(input);
  const total = r.allocations.filter((a) => a.accountId === goalA.id).reduce((s, a) => s + a.amount, 0);
  assertEqual(total, 5000, "8-أ: مهما بلغ الفائض، الهدف لا يحصل إلا على minAllocation بالضبط (5,000) — لا مرحلة ترفعه فوق ذلك");
}

console.log("\n========== 9) اختبارات مركَّبة (عدة قواعد في سيناريو واحد) ==========\n");
{
  // عجز مرحّل لمصروف + هدف حرج جديد + دين مستمر عند حده الأعلى + دخل غير كافٍ للجميع
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 12000,
    expenses: [{ account: food, monthlyMin: 8000, monthlyMax: 12000, priority: "essential_high", carriedDeficit: 2000 }],
    goals: [{ account: goalA, minAllocation: 3000, maxAllocation: 3000, targetAmount: 50000, achievedAmount: 0, priority: "critical" }],
    oneTimeDebts: [],
    recurringDebts: [{ account: rdebt, currentBalance: 55000, minLimit: 10000, maxLimit: 50000 }],
  };
  const r = runDistribution(input);
  // Stage0.1: عجز الطعام 2,000 يُموَّل بالكامل (متاح=12,000) → متبقٍ 10,000
  // Stage1.1: طعام monthlyMin=8,000 → يُموَّل بالكامل → متبقٍ 2,000
  // نقص عن التغطية الكاملة؟ لا، كلاهما مُوِّل بالكامل. Stage1 لا يوجد نقص → يستمر
  assertTrue(!r.insufficientAllocationReport, "9-أ: لا نقص — كل الحدود الدنيا (Stage0+Stage1) مُوِّلت بالكامل");
  const foodStage0 = r.allocations.find((a) => a.accountId === food.id && a.stage === 0);
  const foodStage1 = r.allocations.find((a) => a.accountId === food.id && a.stage === 1);
  assertEqual(foodStage0?.amount, 2000, "9-ب: عجز الطعام المرحّل (2,000) سطر منفصل في Stage 0.1");
  assertEqual(foodStage1?.amount, 8000, "9-ج: الحد الأدنى الجديد (8,000) سطر منفصل في Stage 1 — لا دمج مع العجز");
  // متبقٍ بعد Stage0+1 = 12,000-2,000-8,000=2,000. Stage2: هدف حرج 3,000 لكن المتاح فقط 2,000
  const goalStage2 = r.allocations.find((a) => a.accountId === goalA.id && a.stage === 2);
  assertEqual(goalStage2?.amount, 2000, "9-د: الهدف الحرج يُموَّل جزئيًا (2,000 من أصل 3,000) — لا نقص يوقف كل شيء لأن هذا اختياري بعد Stage1 لا Stage1 نفسها");
  // لا شيء يتبقى للدين المستمر رغم أنه عند حده الأعلى (فوق حتى)
  const rdebtNote = r.recurringDebtResults.find((n) => n.accountId === rdebt.id);
  assertEqual(rdebtNote?.forcedPaydownAmount ?? 0, 0, "9-هـ: الدين المستمر (رغم بلوغه ما فوق الحد الأعلى) لا يحصل على شيء — استُهلك كل الدخل في Stage0-2 الأعلى أولوية");
}
{
  // اختبار مركَّب ثانٍ: isNonDeferrable + دين لمرة واحدة + دين مستمر معًا
  const flatFood = [{ account: food, monthlyMin: 5000, monthlyMax: 5000, priority: "essential" as const }];
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 5000 + 4000 + 6000, // مصروف + التزام غير قابل للتأجيل + دين لمرة واحدة
    expenses: flatFood,
    goals: [{ account: goalA, minAllocation: 4000, maxAllocation: 4000, targetAmount: 40000, achievedAmount: 0, priority: "moderate", isNonDeferrable: true }],
    oneTimeDebts: [{ account: debtOnce, remainingBalance: 6000, priority: "urgent_moderate" }],
    recurringDebts: [],
  };
  const r = runDistribution(input);
  const goalStage1 = r.allocations.find((a) => a.accountId === goalA.id && a.stage === 1);
  assertEqual(goalStage1?.amount, 4000, "9-و: هدف isNonDeferrable=true (أولوية moderate) يُموَّل بالكامل ضمن Stage 1.2 رغم أولويته المنخفضة أصلًا");
  const debtStage5 = r.allocations.find((a) => a.accountId === debtOnce.id && a.stage === 5);
  assertEqual(debtStage5?.amount, 6000, "9-ز: الدين لمرة واحدة يُموَّل بالكامل من الباقي بعد Stage1 (Stage5)");
}

console.log("\n========== 10) Stage 0 بمجموعاته الأربع، تواريخ استحقاق متداخلة ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 1000, // يكفي عنصرًا واحدًا فقط من كل هذه العناصر المتنافسة
    expenses: [{ account: food, monthlyMin: 0, monthlyMax: 0, priority: "essential_high", carriedDeficit: 1000, dueDate: "2026-09-05" }],
    goals: [{ account: goalA, minAllocation: 0, maxAllocation: 0, targetAmount: 0, achievedAmount: 0, priority: "critical", carriedDeficit: 1000, dueDate: "2026-09-01" }],
    oneTimeDebts: [{ account: debtOnce, remainingBalance: 0, priority: "urgent_high", carriedDeficit: 1000, dueDate: "2026-09-01" }],
    recurringDebts: [],
    reserve: { account: reserve, carriedDeficit: 1000 },
  };
  const r = runDistribution(input);
  const s0 = r.allocations.filter((a) => a.stage === 0);
  // المجموعات بترتيب ثابت: مصروفات(0.1) أولًا مهما كان تاريخ الاستحقاق أو الأولوية — قبل الالتزامات(0.2) قبل الأهداف(0.3) قبل الاحتياطي(0.4)
  assertEqual(s0.find((a) => a.accountId === food.id)?.amount, 1000, "10-أ: عجز المصروفات (المجموعة 0.1) يُموَّل أولًا دائمًا، حتى مع تاريخ استحقاق أبعد من الالتزامات");
  assertEqual(s0.find((a) => a.accountId === debtOnce.id)?.amount ?? 0, 0, "10-ب: لا شيء يتبقى لمجموعة الالتزامات (0.2) رغم أن تاريخ استحقاقها أقرب — ترتيب المجموعات أعلى من التاريخ");
  assertEqual(s0.find((a) => a.accountId === goalA.id)?.amount ?? 0, 0, "10-ج: ولا شيء لمجموعة الأهداف (0.3)");
  assertEqual(s0.find((a) => a.accountId === reserve.id)?.amount ?? 0, 0, "10-د: ولا شيء لمجموعة الاحتياطي (0.4)، آخر المجموعات دائمًا");
}

console.log("\n========== 11) isNonDeferrable لهدف جديد يُفرَض تمويله ضمن Stage 1 قبل Stage 2 ==========\n");
{
  const input: DistributionInput = {
    periodId: "p",
    incomeAvailable: 4000,
    expenses: [],
    goals: [
      { account: goalA, minAllocation: 4000, maxAllocation: 4000, targetAmount: 40000, achievedAmount: 0, priority: "moderate", isNonDeferrable: true },
      { account: goalB, minAllocation: 4000, maxAllocation: 4000, targetAmount: 40000, achievedAmount: 0, priority: "critical" }, // أولوية أعلى لكن ليس isNonDeferrable
    ],
    oneTimeDebts: [], recurringDebts: [],
  };
  const r = runDistribution(input);
  const aStage1 = r.allocations.find((a) => a.accountId === goalA.id && a.stage === 1);
  const bStage2 = r.allocations.find((a) => a.accountId === goalB.id && a.stage === 2);
  assertEqual(aStage1?.amount, 4000, "11-أ: goalA (isNonDeferrable) يُموَّل بالكامل في Stage 1 رغم أولويته الأدنى (moderate)");
  assertEqual(bStage2?.amount ?? 0, 0, "11-ب: goalB (critical لكن ليس isNonDeferrable) لا يحصل على شيء — نفد المتاح في Stage 1 قبل وصول Stage 2");
}

console.log("\n========== 12) انفصال reducedMinLimitBy/reducedBalanceBy بأرقام المستخدم بالضبط ==========\n");
{
  // الرصيد=42,000 min=10,000 max=50,000 → سداد فعلي منفصل 9,000 (خارج المحرك، محاكاة) → الرصيد الجديد=33,000
  const balanceAfterManualPayment = 33000;
  const state: RecurringDebtState = { accountId: rdebt.id, balance: balanceAfterManualPayment, minLimit: 10000, maxLimit: 50000 };
  assertEqual(determineStage(state), "rising", "12-أ: بعد السداد اليدوي، الحالة rising (33,000 بين 10,000 و50,000)");

  // فائض إضافي 12,000 يُخصَّص لهذا الحساب لاحقًا في Stage 6ب (محاكاة مباشرة للدالة الأساسية)
  const result = reduceMinThenBalance(state, 12000);
  assertEqual(result.reducedMinLimitBy, 10000, "12-ب: كم ذهب لتخفيض الحد الأدنى = 10,000 بالضبط");
  assertEqual(result.reducedBalanceBy, 2000, "12-ج: كم ذهب لتخفيض الرصيد = 2,000 بالضبط");
  assertEqual(result.newMinLimitProposed, 0, "12-د: الحد الأدنى الجديد المقترح = 0");
  assertEqual(result.newBalanceProjected, 31000, "12-هـ: الرصيد الجديد المُسقَط = 31,000");
  assertEqual(determineStage({ ...state, balance: result.newBalanceProjected, minLimit: result.newMinLimitProposed }), "final_payoff", "12-و: المرحلة التالية = final_payoff");
}

console.log(`\n\n=== نتيجة اختبارات المواصفة v3: ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
if (failed > 0) {
  console.log("الاختبارات الفاشلة:");
  failures.forEach((f) => console.log(`  - ${f}`));
}
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
