// ============================================================
// اختبارات الملاحظة 3: إعادة تصميم التقارير عند الطباعة.
// تغطي تحديدًا متطلبات إعادة التصميم نفسها (أعمدة كشف الحساب الستة بالضبط، طي الحساب
// المقابل داخل البيان، عدم وجود أعمدة تقنية، تكامل renderReportToHtml مع كتلة الإجماليات
// البارزة) — لا تكرر ما تغطيه reports.test.ts / account-statement.test.ts / transaction-
// log.test.ts من احتساب الأرصدة والفلاتر (غير متغيّر إطلاقًا في هذه الملاحظة).
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { recordIncome, recordExpense } from "../src/transactions";
import { computeDisplayOperationNumbers } from "../src/repository";
import { buildAccountLedgerReport, buildTransactionLogReport, renderReportToHtml, TransactionLogEntry } from "../src/reports";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
function acc(id: string, name: string, category: Account["category"], opening = 0): Account {
  return { id, name, category, openingBalance: opening, status: "active" };
}
function withDisplayNumbers(entries: JournalEntry[]): TransactionLogEntry[] {
  const map = computeDisplayOperationNumbers(entries);
  return entries.map((e) => ({ ...e, displayOperationNumber: map.get(e.id)! }));
}

const wallet = acc("acc_wallet", "المحفظة", "pot");
const salary = acc("acc_salary", "الراتب", "income_source");
const food = acc("acc_food", "طعام", "expense");
const allAccounts = [wallet, salary, food];

console.log("=== 1) كشف الحساب: الأعمدة الستة بالضبط، بنفس الترتيب المطلوب حرفيًا ===\n");
{
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries: [] });
  assertEqual(report.columns, ["التاريخ", "رقم العملية", "البيان", "دائن", "مدين", "الرصيد"], "1-أ: أعمدة كشف الحساب هي بالضبط الستة المطلوبة وبنفس الترتيب");
  assertEqual(report.columns.length, 6, "1-ب: ستة أعمدة فقط — لا أكثر");
}

console.log("\n=== 2) لا عمود 'الحساب المقابل' مستقل، ولا عمود 'نوع العملية' مستقل ===\n");
{
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries: [] });
  assertTrue(!report.columns.includes("الحساب المقابل"), "2-أ: لا يوجد عمود 'الحساب المقابل' مستقل بعد الآن");
  assertTrue(!report.columns.includes("نوع العملية"), "2-ب: لا يوجد عمود 'نوع العملية' مستقل بعد الآن");
  assertTrue(!report.columns.includes("المعرف الداخلي") && !report.columns.some((c) => c.toLowerCase().includes("id")), "2-ج: لا عمود بأي معرّف داخلي");
}

console.log("\n=== 3) اسم الحساب المقابل مطويّ فعليًا داخل 'البيان' عند وجوده ===\n");
{
  const entries: JournalEntry[] = [recordIncome(salary, wallet, 5000, "2026-09-01", "p1")];
  const report = buildAccountLedgerReport({ account: wallet, allAccounts, entries });
  const statementColIndex = report.columns.indexOf("البيان");
  assertTrue(statementColIndex !== -1, "3-أ: عمود 'البيان' موجود");
  assertTrue(report.rows[0][statementColIndex].includes("الراتب"), "3-ب: البيان يتضمَّن اسم الحساب المقابل (الراتب) فعليًا");
}

console.log("\n=== 4) الرصيد الافتتاحي والإجماليات والرصيد النهائي واضحة في totals (لم تتغيّر رغم إعادة تصميم الأعمدة) ===\n");
{
  const w = acc("acc_w_open", "محفظة بافتتاحي", "pot", 5000);
  const entries: JournalEntry[] = [
    recordIncome(salary, w, 1000, "2026-09-01", "p1"),
    recordExpense(food, w, 300, "2026-09-02", "p1", false, 1000),
  ];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries });
  assertTrue("الرصيد الافتتاحي" in (report.totals || {}), "4-أ: الرصيد الافتتاحي موجود في totals");
  assertTrue("إجمالي مدين" in (report.totals || {}), "4-ب: إجمالي مدين موجود في totals");
  assertTrue("إجمالي دائن" in (report.totals || {}), "4-ج: إجمالي دائن موجود في totals");
  assertTrue("الرصيد النهائي" in (report.totals || {}), "4-د: الرصيد النهائي موجود في totals");
}

console.log("\n=== 5) سجل العمليات: نفس الأسلوب الاحترافي المختصر — أعمدة مناسبة لمحتواه، بلا معرّفات داخلية ===\n");
{
  const e = recordIncome(salary, wallet, 1000, "2026-08-01", "p1");
  const sarMap = new Map(allAccounts.map((a) => [a.id, { code: "SAR", name: "ريال سعودي", symbol: "ر.س" }]));
  const { document: report } = buildTransactionLogReport({ entries: withDisplayNumbers([e]), accounts: allAccounts, accountCurrencies: sarMap });
  assertEqual(report.columns, ["رقم العملية", "التاريخ", "البيان", "الحساب المدين", "الحساب الدائن", "المبلغ", "العملة"], "5-أ: أعمدة سجل العمليات مختصرة ومناسبة لمحتواه");
  assertTrue(!report.columns.includes("نوع العملية"), "5-ب: لا عمود 'نوع العملية' مستقل بعد الآن (مطويّ داخل البيان)");
  const html = renderReportToHtml(report);
  assertTrue(!html.includes(wallet.id) && !html.includes(salary.id) && !html.includes(e.id), "5-ج: لا معرّف داخلي واحد يظهر في HTML المطبوع");
}

console.log("\n=== 6) renderReportToHtml: ترويسة احترافية + إبراز الرصيد النهائي + بلا أي معرّف داخلي ===\n");
{
  const w: Account = { id: "acc_secret_id_123", name: "محفظة", category: "pot", openingBalance: 0, status: "active" };
  const entries: JournalEntry[] = [recordIncome(salary, w, 1000, "2026-09-01", "p1")];
  const report = buildAccountLedgerReport({ account: w, allAccounts: [...allAccounts, w], entries });
  const html = renderReportToHtml(report);

  assertTrue(html.includes("إسناد — مديرك المالي الشخصي"), "6-أ: اسم التطبيق ظاهر في ترويسة المستند المطبوع");
  assertTrue(html.includes("report-header"), "6-ب: كتلة ترويسة منفصلة (report-header) موجودة — ليست مجرد جدول");
  assertTrue(html.includes('class="report-total-row final"'), "6-ج: صف 'الرصيد النهائي' يحمل تنسيق الإبراز (final) في HTML");
  assertTrue(!html.includes(w.id), "6-د: المعرّف الداخلي للحساب (acc_secret_id_123) لا يظهر إطلاقًا في المستند المطبوع");
  assertTrue(!html.includes(salary.id), "6-هـ: ولا معرّف الحساب المقابل الداخلي أيضًا");
}

console.log(`\n\n=== النتيجة الإجمالية لاختبارات إعادة تصميم التقارير والطباعة (الملاحظة 3): ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
declare const process: { exit: (code: number) => void };
if (failed > 0) process.exit(1);
