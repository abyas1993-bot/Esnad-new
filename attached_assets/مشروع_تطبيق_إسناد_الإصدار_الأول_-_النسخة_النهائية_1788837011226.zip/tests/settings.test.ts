// ============================================================
// اختبارات الملاحظة 1: تبويب الإعدادات — إدارة العملات + العملة الافتراضية + النسخ
// الاحتياطي والاستعادة. لا تلمس محرك القيود/التوزيع/الإغلاق — تغطي فقط الإضافات الجديدة
// في currency.ts وrepository.ts وbackup.ts وstorage.ts (replaceAllData).
// ============================================================
import { Account, JournalEntry } from "../src/types";
import { recordIncome } from "../src/transactions";
import { FileStorageAdapter } from "../src/storage";
import { Repository } from "../src/repository";
import { Currency, DEFAULT_CURRENCY, DuplicateCurrencyCodeError } from "../src/currency";
import { validateBackupFile, InvalidBackupFileError, IncompatibleBackupSchemaVersionError, BACKUP_SCHEMA_VERSION } from "../src/backup";

let passed = 0;
let failed = 0;
function assertEqual(actual: unknown, expected: unknown, label: string) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}\n   متوقَّع: ${JSON.stringify(expected)}\n   فعلي:   ${JSON.stringify(actual)}`); }
}
function assertTrue(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`✅ ${label}`); }
  else { failed++; console.log(`❌ ${label}`); }
}
async function assertRejects(fn: () => Promise<unknown>, errType: Function, label: string) {
  try {
    await fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يُرفَض ولم يُرفَض`);
  } catch (e) {
    if (e instanceof errType) { passed++; console.log(`✅ ${label}`); }
    else { failed++; console.log(`❌ ${label} — رُفض بخطأ من نوع خاطئ: ${(e as Error).message}`); }
  }
}
function assertThrowsSync(fn: () => unknown, errType: Function, label: string) {
  try {
    fn();
    failed++; console.log(`❌ ${label} — كان يجب أن يرمي خطأ ولم يفعل`);
  } catch (e) {
    if (e instanceof errType) { passed++; console.log(`✅ ${label}`); }
    else { failed++; console.log(`❌ ${label} — رُمي خطأ من نوع خاطئ: ${(e as Error).message}`); }
  }
}
function acc(id: string, name: string, category: Account["category"]): Account {
  return { id, name, category, openingBalance: 0, status: "active" };
}

declare const require: (id: string) => any;
const DB_FILE = "/tmp/isnad_test_settings_db.json";

async function main() {
  const fs = require("fs");
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);

  console.log("=== 1) إضافة عملة جديدة عبر Repository.addCurrency ===\n");
  {
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const yer: Currency = { code: "YER", name: "ريال يمني", symbol: "﷼" };
    await repo.addCurrency(yer);
    const all = await repo.getAllCurrencies();
    assertEqual(all.length, 1, "1-أ: العملة الجديدة (YER) أُضيفت بنجاح");
    assertEqual(all[0].code, "YER", "1-ب: كود العملة المحفوظة صحيح");

    await assertRejects(() => repo.addCurrency({ code: "YER", name: "نسخة مكررة", symbol: "x" }), DuplicateCurrencyCodeError, "1-ج: رفض إضافة عملة بنفس الكود المكرر (YER)");
    assertEqual((await repo.getAllCurrencies()).length, 1, "1-د: المحاولة المكررة المرفوضة لم تُضِف أو تُعدِّل شيئًا");

    await assertRejects(() => repo.addCurrency({ code: "", name: "بلا كود", symbol: "x" }), Error, "1-هـ: رفض عملة بكود فارغ");
    await assertRejects(() => repo.addCurrency({ code: "OM", name: "", symbol: "x" }), Error, "1-و: رفض عملة باسم فارغ");
    await assertRejects(() => repo.addCurrency({ code: "OMR", name: "ريال عُماني", symbol: "" }), Error, "1-ز: رفض عملة برمز عرض فارغ");
  }

  console.log("\n=== 2) العملة الافتراضية للتطبيق: اختيار، وحيدة دائمًا، وSAR تبقى متاحة ===\n");
  {
    const fs2 = require("fs");
    if (fs2.existsSync(DB_FILE)) fs2.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    await repo.ensureDefaultCurrency(); // يضيف SAR كعملة بداية (بلا isDefault صريح)
    assertEqual(await repo.getDefaultCurrency(), DEFAULT_CURRENCY, "2-أ: قبل أي اختيار صريح — العملة الافتراضية المقترحة هي SAR (سلوك بديهي متوافق مع السابق)");

    await repo.addCurrency({ code: "YER", name: "ريال يمني", symbol: "﷼" });
    await repo.setDefaultCurrency("YER");
    const def1 = await repo.getDefaultCurrency();
    assertEqual(def1.code, "YER", "2-ب: بعد اختيار YER كافتراضية — getDefaultCurrency تعيد YER");

    const allAfterYer = await repo.getAllCurrencies();
    const sarStill = allAfterYer.find((c) => c.code === "SAR");
    assertTrue(!!sarStill, "2-ج: SAR ما زالت موجودة في قائمة العملات (لم تُحذف)");
    assertTrue(!sarStill?.isDefault, "2-د: SAR لم تعد افتراضية بعد اختيار YER");

    await repo.addCurrency({ code: "OMR", name: "ريال عُماني", symbol: "ر.ع" });
    await repo.setDefaultCurrency("OMR");
    const def2 = await repo.getDefaultCurrency();
    assertEqual(def2.code, "OMR", "2-هـ: تغيير الاختيار إلى OMR ينجح فعليًا");

    const allAfterOmr = await repo.getAllCurrencies();
    const defaultCount = allAfterOmr.filter((c) => c.isDefault === true).length;
    assertEqual(defaultCount, 1, "2-و: عملة افتراضية واحدة فقط على الإطلاق بعد عدة تبديلات (YER ثم OMR)");
    assertTrue(allAfterOmr.some((c) => c.code === "SAR"), "2-ز: SAR ما زالت متاحة حتى بعد اختيار OMR كافتراضية");
    assertTrue(allAfterOmr.some((c) => c.code === "YER"), "2-ح: YER ما زالت متاحة أيضًا (لم تُحذف عند تبديل الافتراضية عنها)");

    await assertRejects(() => repo.setDefaultCurrency("EGP"), Error, "2-ط: رفض تعيين عملة افتراضية لكود غير موجود أصلًا");
  }

  console.log("\n=== 3) تغيير العملة الافتراضية لا يمسّ أي بيانات مالية سابقة ===\n");
  {
    const fs3 = require("fs");
    if (fs3.existsSync(DB_FILE)) fs3.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.addCurrency({ code: "YER", name: "ريال يمني", symbol: "﷼" });
    await repo.saveAccountCurrencyLink({ accountId: wallet.id, currencyCode: "YER" });
    const entry = recordIncome(salary, wallet, 10000, "2026-08-01", "p1");
    await repo.persistJournalEntry(entry);

    const balanceBefore = await repo.getAccountBalance(wallet.id);
    const currencyBefore = await repo.getAccountCurrency(wallet.id);
    const entriesBefore = await repo.getAllJournalEntries();

    await repo.addCurrency({ code: "OMR", name: "ريال عُماني", symbol: "ر.ع" });
    await repo.setDefaultCurrency("OMR"); // تغيير العملة الافتراضية للتطبيق

    const balanceAfter = await repo.getAccountBalance(wallet.id);
    const currencyAfter = await repo.getAccountCurrency(wallet.id);
    const entriesAfter = await repo.getAllJournalEntries();

    assertEqual(balanceAfter, balanceBefore, "3-أ: رصيد الوعاء (الرابط بـYER صراحةً) لم يتغيّر إطلاقًا بعد تغيير الافتراضية إلى OMR");
    assertEqual(currencyAfter, currencyBefore, "3-ب: عملة الوعاء الفعلية ما زالت YER (الرابط الصريح لا يتأثر بتغيير الافتراضية)");
    assertEqual(currencyAfter.code, "YER", "3-ج: تأكيد إضافي: لم تُجبَر على OMR رغم كونها الافتراضية الجديدة");
    assertEqual(entriesAfter, entriesBefore, "3-د: القيود الفعلية المخزَّنة لم تتغيّر حرفًا واحدًا");
  }

  console.log("\n=== 4) النسخ الاحتياطي: exportBackup يشمل كل المخازن السبعة ===\n");
  {
    const fs4 = require("fs");
    if (fs4.existsSync(DB_FILE)) fs4.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const wallet = acc("acc_wallet", "المحفظة", "pot");
    const salary = acc("acc_salary", "الراتب", "income_source");
    await repo.saveAccount(wallet);
    await repo.saveAccount(salary);
    await repo.persistJournalEntry(recordIncome(salary, wallet, 5000, "2026-08-01", "p1"));
    await repo.openPeriod({ id: "p1", startDate: "2026-08-01", endDate: "2026-08-31", status: "open" });
    await repo.addCurrency({ code: "SAR", name: "ريال سعودي", symbol: "ر.س" });
    await repo.saveAccountCurrencyLink({ accountId: wallet.id, currencyCode: "SAR" });

    const backup = await repo.exportBackup();
    assertEqual(backup.schemaVersion, BACKUP_SCHEMA_VERSION, "4-أ: schemaVersion الصادر يطابق الإصدار الحالي المدعوم");
    assertTrue(typeof backup.exportedAt === "string" && backup.exportedAt.length > 0, "4-ب: exportedAt موجود ونصّي");
    assertEqual(backup.data.accounts.length, 2, "4-ج: حسابان في النسخة الاحتياطية");
    assertEqual(backup.data.journalEntries.length, 1, "4-د: قيد واحد في النسخة الاحتياطية");
    assertEqual(backup.data.periods.length, 1, "4-هـ: فترة واحدة في النسخة الاحتياطية");
    assertEqual(backup.data.currencies.length, 1, "4-و: عملة واحدة في النسخة الاحتياطية");
    assertEqual(backup.data.accountCurrencyLinks.length, 1, "4-ز: ربط عملة واحد في النسخة الاحتياطية");
    assertEqual(backup.data.periodCloseResults.length, 0, "4-ح: لا سجلات إغلاق بعد (فارغة، وليست غائبة)");
    assertEqual(backup.data.planningSettings.length, 0, "4-ط: لا إعدادات تخطيط بعد (فارغة، وليست غائبة)");
  }

  console.log("\n=== 5) الاستعادة: نسخة صحيحة تستبدل البيانات فعليًا (وليس دمجًا) ===\n");
  {
    const fs5 = require("fs");
    if (fs5.existsSync(DB_FILE)) fs5.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    // بيانات قديمة قبل الاستعادة — يجب أن تختفي تمامًا بعد استعادة نسخة لا تحتوي عليها
    const oldAccount = acc("acc_old", "حساب قديم قبل الاستعادة", "pot");
    await repo.saveAccount(oldAccount);
    assertEqual((await repo.getAllAccounts()).length, 1, "5-أ (تمهيدي): حساب قديم واحد قبل الاستعادة");

    const freshWallet = acc("acc_new_wallet", "محفظة من النسخة الاحتياطية", "pot");
    const backupToRestore = {
      schemaVersion: BACKUP_SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      data: {
        accounts: [freshWallet],
        journalEntries: [] as JournalEntry[],
        periods: [],
        periodCloseResults: [],
        planningSettings: [],
        currencies: [{ code: "SAR", name: "ريال سعودي", symbol: "ر.س" }],
        accountCurrencyLinks: [],
      },
    };

    const restored = await repo.restoreBackup(backupToRestore);
    assertEqual(restored.schemaVersion, BACKUP_SCHEMA_VERSION, "5-ب: restoreBackup تعيد الكائن المُتحقَّق منه");

    const accountsAfterRestore = await repo.getAllAccounts();
    assertEqual(accountsAfterRestore.length, 1, "5-ج: بعد الاستعادة — حساب واحد فقط (من النسخة الاحتياطية)");
    assertEqual(accountsAfterRestore[0].id, "acc_new_wallet", "5-د: الحساب القديم اختفى تمامًا — استبدال كامل وليس دمجًا");
    assertEqual((await repo.getAllCurrencies()).length, 1, "5-هـ: عملة واحدة فقط بعد الاستعادة (من النسخة الاحتياطية)");
  }

  console.log("\n=== 6) رفض نسخة تالفة أو غير صالحة دون تغيير أي بيانات حالية ===\n");
  {
    const fs6 = require("fs");
    if (fs6.existsSync(DB_FILE)) fs6.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const wallet = acc("acc_wallet", "المحفظة", "pot");
    await repo.saveAccount(wallet);
    const balanceBefore = await repo.getAccountBalance(wallet.id);
    const accountsBefore = await repo.getAllAccounts();

    // 6-أ: ليس كائنًا أصلًا
    await assertRejects(() => repo.restoreBackup("نص وليس JSON كائن"), InvalidBackupFileError, "6-أ: رفض ملف ليس كائن JSON");

    // 6-ب: بلا schemaVersion
    await assertRejects(() => repo.restoreBackup({ exportedAt: "x", data: {} }), InvalidBackupFileError, "6-ب: رفض ملف بلا schemaVersion");

    // 6-ج: schemaVersion غير متوافق
    await assertRejects(
      () => repo.restoreBackup({ schemaVersion: 999, exportedAt: "x", data: { accounts: [], journalEntries: [], periods: [], periodCloseResults: [], planningSettings: [], currencies: [], accountCurrencyLinks: [] } }),
      IncompatibleBackupSchemaVersionError,
      "6-ج: رفض schemaVersion غير متوافق (999)"
    );

    // 6-د: data.accounts ليست قائمة
    await assertRejects(
      () => repo.restoreBackup({ schemaVersion: BACKUP_SCHEMA_VERSION, exportedAt: "x", data: { accounts: "ليست قائمة", journalEntries: [], periods: [], periodCloseResults: [], planningSettings: [], currencies: [], accountCurrencyLinks: [] } }),
      InvalidBackupFileError,
      "6-د: رفض data.accounts ليست قائمة"
    );

    // 6-هـ: سجل حساب ناقص الحقول
    await assertRejects(
      () => repo.restoreBackup({ schemaVersion: BACKUP_SCHEMA_VERSION, exportedAt: "x", data: { accounts: [{ id: "x" }], journalEntries: [], periods: [], periodCloseResults: [], planningSettings: [], currencies: [], accountCurrencyLinks: [] } }),
      InvalidBackupFileError,
      "6-و: رفض سجل حساب ناقص الحقول المطلوبة"
    );

    // 6-ز: قيد غير متوازن شكليًا (سطر بمبلغ سالب)
    await assertRejects(
      () =>
        repo.restoreBackup({
          schemaVersion: BACKUP_SCHEMA_VERSION,
          exportedAt: "x",
          data: {
            accounts: [],
            journalEntries: [{ id: "je1", entryDate: "2026-01-01", transactionType: "income", periodId: "p1", lines: [{ accountId: "a", direction: "DEBIT", amount: -5 }] }],
            periods: [],
            periodCloseResults: [],
            planningSettings: [],
            currencies: [],
            accountCurrencyLinks: [],
          },
        }),
      InvalidBackupFileError,
      "6-ح: رفض قيد يحتوي سطرًا بمبلغ سالب/صفري"
    );

    const balanceAfter = await repo.getAccountBalance(wallet.id);
    const accountsAfter = await repo.getAllAccounts();
    assertEqual(balanceAfter, balanceBefore, "6-ط: رصيد الحساب الحالي لم يتغيّر بعد كل محاولات الاستعادة المرفوضة");
    assertEqual(accountsAfter, accountsBefore, "6-ي: قائمة الحسابات الحالية لم تتغيّر إطلاقًا بعد كل المحاولات المرفوضة");
  }

  console.log("\n=== 7) validateBackupFile: اختبار مباشر لدالة التحقق النقية (بلا تخزين) ===\n");
  {
    const validRaw = {
      schemaVersion: BACKUP_SCHEMA_VERSION,
      exportedAt: "2026-09-01T00:00:00.000Z",
      data: {
        accounts: [{ id: "a1", name: "حساب", category: "pot", openingBalance: 0, status: "active" }],
        journalEntries: [],
        periods: [],
        periodCloseResults: [],
        planningSettings: [],
        currencies: [{ code: "SAR", name: "ريال سعودي", symbol: "ر.س" }],
        accountCurrencyLinks: [],
      },
    };
    const result = validateBackupFile(validRaw);
    assertEqual(result.data.accounts.length, 1, "7-أ: نسخة صحيحة كاملة البنية تمر بلا استثناء");

    assertThrowsSync(() => validateBackupFile(null), InvalidBackupFileError, "7-ب: رفض null مباشرة");
    assertThrowsSync(() => validateBackupFile(42), InvalidBackupFileError, "7-ج: رفض رقم بدل كائن");
    assertThrowsSync(() => validateBackupFile({ schemaVersion: 1, exportedAt: "x", data: { accounts: [] } }), InvalidBackupFileError, "7-د: رفض data بحقول ناقصة (بلا journalEntries وغيرها)");
  }

  console.log("\n=== 8) الاستعادة الذرّية (قدر الإمكان) عبر replaceAllData: استبدال دفعة واحدة صحيحًا ===\n");
  {
    const fs8 = require("fs");
    if (fs8.existsSync(DB_FILE)) fs8.unlinkSync(DB_FILE);
    const storage = new FileStorageAdapter(DB_FILE);
    const repo = new Repository(storage);

    const a1 = acc("a1", "حساب 1", "pot");
    const a2 = acc("a2", "حساب 2", "expense");
    await storage.replaceAllData({
      accounts: [a1, a2],
      journalEntries: [],
      periods: [{ id: "p1", startDate: "2026-01-01", endDate: "2026-01-31", status: "open" }],
      periodCloseResults: [],
      planningSettings: [],
      currencies: [{ code: "SAR", name: "ريال سعودي", symbol: "ر.س" }],
      accountCurrencyLinks: [{ accountId: "a1", currencyCode: "SAR" }],
    });

    const accountsAfter = await repo.getAllAccounts();
    assertEqual(accountsAfter.length, 2, "8-أ: replaceAllData يكتب كل السجلات دفعة واحدة بنجاح (حسابان)");
    assertEqual((await storage.getAllFinancialPeriods()).length, 1, "8-ب: الفترة المُستبدَلة محفوظة");
    assertEqual((await repo.getAllCurrencies())[0].code, "SAR", "8-ج: العملة المُستبدَلة محفوظة");
    assertEqual((await repo.getAllAccountCurrencyLinks())[0].accountId, "a1", "8-د: ربط العملة المُستبدَل محفوظ");

    // استدعاء ثانٍ يستبدل كل شيء مرة أخرى بالكامل (وليس دمجًا مع السابق)
    await storage.replaceAllData({
      accounts: [acc("a3", "حساب 3", "goal")],
      journalEntries: [],
      periods: [],
      periodCloseResults: [],
      planningSettings: [],
      currencies: [],
      accountCurrencyLinks: [],
    });
    const accountsAfterSecond = await repo.getAllAccounts();
    assertEqual(accountsAfterSecond.length, 1, "8-هـ: الاستبدال الثاني محا كل شيء من الاستبدال الأول (a1/a2) وأبقى فقط a3");
    assertEqual(accountsAfterSecond[0].id, "a3", "8-و: الحساب الوحيد المتبقي هو a3 كما في الاستبدال الثاني بالضبط");
  }

  console.log(`\n\n=== النتيجة الإجمالية لاختبارات الإعدادات (الملاحظة 1): ${passed} ناجح، ${failed} فاشل من أصل ${passed + failed} ===`);
  const fsFinal = require("fs");
  if (fsFinal.existsSync(DB_FILE)) fsFinal.unlinkSync(DB_FILE);
  if (failed > 0) process.exit(1);
}

declare const process: { exit: (code: number) => void };
main().catch((e) => {
  console.error("خطأ غير متوقع أثناء تشغيل اختبارات الإعدادات:", e);
  process.exit(1);
});
