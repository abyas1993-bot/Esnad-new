// يبني حزمة ويب ذاتية الاحتواء (كل الملفات بمسارات نسبية صحيحة داخل مجلد واحد)
// لتُستخدَم كـwebDir في Capacitor — بلا أي تعديل على منطق src/ نفسه، نسخ + إعادة كتابة مسارات فقط.
const fs = require("fs");
const path = require("path");

const OUT = "dist-capacitor";
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(path.join(OUT, "src"), { recursive: true });
fs.mkdirSync(path.join(OUT, "icons"), { recursive: true });

// 1) index.html — نسخ مع تعديل مسارات السكربت والأيقونات لتكون محلية (بلا ../web-dist/)
let html = fs.readFileSync("web/index.html", "utf-8");
html = html.replace('src="../web-dist/web/app.js"', 'src="./app.js"');
html = html.replace('href="manifest.json"', 'href="./manifest.json"');
html = html.replace('href="icons/icon-192.png" />\n<link rel="apple-touch-icon" href="icons/icon-192.png"',
                     'href="./icons/icon-192.png" />\n<link rel="apple-touch-icon" href="./icons/icon-192.png"');
fs.writeFileSync(path.join(OUT, "index.html"), html);

// 2) app.js — نسخ مع تعديل استيراد "../src/xxx.js" إلى "./src/xxx.js" (نفس المستوى الآن)
let appJs = fs.readFileSync("web-dist/web/app.js", "utf-8");
appJs = appJs.replace(/from "\.\.\/src\//g, 'from "./src/');
fs.writeFileSync(path.join(OUT, "app.js"), appJs);

// 3) ملفات النواة src/*.js — نسخ مباشر (استيراداتها الداخلية "./xxx.js" بينها صحيحة أصلًا بلا تغيير)
for (const f of fs.readdirSync("web-dist/src")) {
  fs.copyFileSync(path.join("web-dist/src", f), path.join(OUT, "src", f));
}

// 4) manifest + أيقونات + Service Worker (sw.js يستخدم مسارات "../web-dist/..." يجب تعديلها أيضًا)
let manifest = fs.readFileSync("web/manifest.json", "utf-8");
fs.writeFileSync(path.join(OUT, "manifest.json"), manifest);

for (const f of fs.readdirSync("web/icons")) {
  fs.copyFileSync(path.join("web/icons", f), path.join(OUT, "icons", f));
}

let sw = fs.readFileSync("web/sw.js", "utf-8");
sw = sw.replace(/"\.\.\/web-dist\/web\/app\.js"/, '"app.js"');
sw = sw.replace(/"\.\.\/web-dist\/src\//g, '"src/');
fs.writeFileSync(path.join(OUT, "sw.js"), sw);

console.log("dist-capacitor/ built:", fs.readdirSync(OUT));
